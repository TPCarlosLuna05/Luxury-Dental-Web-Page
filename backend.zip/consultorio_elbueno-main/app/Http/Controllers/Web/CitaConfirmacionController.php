<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Citas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

class CitaConfirmacionController extends Controller
{
    /**
     * Muestra la página de confirmación de citas.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $token
     * @return \Illuminate\View\View
     */
    public function mostrarConfirmacion(Request $request, $token)
    {
        // Verificar si el token de confirmación es válido
        if (!$request->hasValidSignature()) {
            return redirect()->route('confirmacion.expirada');
        }

        // Buscar la cita por el token de confirmación
        $cita = Citas::where('confirmation_token', $token)
                    ->with(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos'])
                    ->first();

        if (!$cita) {
            return view('citas.confirmar')
                    ->with('status', 'error')
                    ->with('message', 'El enlace de confirmación no es válido.');
        }

        return view('citas.confirmar', [
            'cita' => $cita,
            'token' => $token
        ]);
    }

    /**
     * Procesa la acción de confirmación o cancelación de la cita.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $token
     * @return \Illuminate\Http\RedirectResponse
     */
    public function procesarConfirmacion(Request $request, $token)
    {
        // Buscar la cita por el token de confirmación
        $cita = Citas::where('confirmation_token', $token)
                    ->with(['paciente', 'doctor', 'procedimiento'])
                    ->first();

        if (!$cita) {
            return redirect()->route('confirmacion.mostrar', ['token' => $token])
                    ->with('status', 'error')
                    ->with('message', 'El enlace de confirmación no es válido.');
        }

        // Verificar si la cita ya fue confirmada
        if ($cita->patient_confirmed) {
            return redirect()->route('confirmacion.mostrar', ['token' => $token])
                    ->with('status', 'warning')
                    ->with('message', 'Esta cita ya ha sido confirmada anteriormente.');
        }

        // Procesar la acción según el botón presionado
        $action = $request->input('action');

        if ($action === 'confirm') {
            // Confirmar la cita
            $cita->confirmarCita();
            
            return redirect()->route('confirmacion.mostrar', ['token' => $token])
                    ->with('status', 'success')
                    ->with('message', '¡Gracias por confirmar su cita! Lo esperamos en la fecha y hora indicada.');
        } elseif ($action === 'cancel') {
            // Cancelar la cita
            $cita->estado = 'Cancelada';
            $cita->observaciones = ($cita->observaciones ? $cita->observaciones . ' | ' : '') . 'Cancelada por el paciente';
            $cita->save();
            
            return redirect()->route('confirmacion.mostrar', ['token' => $token])
                    ->with('status', 'warning')
                    ->with('message', 'La cita ha sido cancelada. Si desea reprogramarla, por favor contacte al consultorio.');
        }

        return redirect()->route('confirmacion.mostrar', ['token' => $token])
                ->with('status', 'error')
                ->with('message', 'Acción inválida.');
    }

    /**
     * Muestra la página cuando el enlace de confirmación ha expirado.
     *
     * @return \Illuminate\View\View
     */
    public function enlaceExpirado()
    {
        return view('citas.enlace-expirado');
    }
}

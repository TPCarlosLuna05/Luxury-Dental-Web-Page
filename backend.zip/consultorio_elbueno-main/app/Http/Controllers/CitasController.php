<?php

namespace App\Http\Controllers;

use App\Models\Citas;
use App\Models\Doctor;
use App\Models\Paciente;
use App\Models\Servicio;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CitasController extends Controller
{
    /**
     * Obtiene las citas según el rol del usuario.
     * - Admin: Todas las citas
     * - Doctor: Solo sus citas asignadas
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        $user = $request->user();
        $query = Citas::with(['doctor', 'paciente', 'procedimiento']);
        
        // Filtrar por fecha si se especifica
        if ($request->has('fecha')) {
            $query->whereDate('fecha', $request->fecha);
        }

        // Filtrar citas según el rol del usuario
        if ($user->rol === 'doctor') {
            $query->where('id_doctor', $user->id_doctor);
        }

        // Aplicar paginación si se solicita
        if ($request->has('per_page')) {
            $citas = $query->paginate($request->per_page);
        } else {
            $citas = $query->get();
        }

        return response()->json([
            'status' => 'success',
            'data' => $citas
        ]);
    }

    /**
     * Almacena una nueva cita en la base de datos.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'id_doctor' => 'required|exists:doctors,id',
            'id_paciente' => 'required|exists:pacientes,id',
            'fecha' => 'required|date|date_format:Y-m-d',
            'hora' => 'required|date_format:H:i',
            'id_procedimiento' => 'nullable|exists:procedimientos,id',
            'notas' => 'nullable|string',
            'estado' => 'required|string|in:programada,confirmada,cancelada,completada,reprogramada'
        ]);

        $user = $request->user();
        
        // Si es un doctor, solo puede crear citas para sí mismo
        if ($user->rol === 'doctor' && $validated['id_doctor'] != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para crear citas para otros doctores'
            ], 403);
        }

        // Verificar que el doctor esté disponible en ese horario
        $citasExistentes = Citas::where('id_doctor', $validated['id_doctor'])
            ->whereDate('fecha', $validated['fecha'])
            ->whereTime('hora', $validated['hora'])
            ->where('estado', '!=', 'cancelada')
            ->count();

        if ($citasExistentes > 0) {
            return response()->json([
                'status' => 'error',
                'message' => 'El doctor ya tiene una cita programada en este horario'
            ], 422);
        }

        // Creamos la cita
        $cita = Citas::create($validated);

        // Calculamos el total basado en los servicios asociados al procedimiento
        if (isset($validated['id_procedimiento'])) {
            $total = Servicio::where('procedimiento_id', $validated['id_procedimiento'])->sum('precio');
            $cita->total = $total;
            $cita->save();
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Cita creada exitosamente',
            'data' => $cita->load(['doctor', 'paciente', 'procedimiento'])
        ], 201);
    }

    /**
     * Obtiene una cita específica.
     *
     * @param Citas $cita
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Citas $cita, Request $request)
    {
        // Verificar que el usuario tenga permiso para ver esta cita
        $user = $request->user();
        if ($user->rol === 'doctor' && $cita->id_doctor != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para ver esta cita'
            ], 403);
        }

        $cita->load(['doctor', 'paciente', 'procedimiento']);

        return response()->json([
            'status' => 'success',
            'data' => $cita
        ]);
    }

    /**
     * Actualiza una cita específica en la base de datos.
     *
     * @param Request $request
     * @param Citas $cita
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Citas $cita)
    {
        // Verificar que el usuario tenga permiso para actualizar esta cita
        $user = $request->user();
        if ($user->rol === 'doctor' && $cita->id_doctor != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para modificar esta cita'
            ], 403);
        }

        $validated = $request->validate([
            'id_doctor' => 'sometimes|exists:doctors,id',
            'id_paciente' => 'sometimes|exists:pacientes,id',
            'fecha' => 'sometimes|date|date_format:Y-m-d',
            'hora' => 'sometimes|date_format:H:i',
            'id_procedimiento' => 'nullable|exists:procedimientos,id',
            'notas' => 'nullable|string',
            'estado' => 'sometimes|string|in:programada,confirmada,cancelada,completada,reprogramada'
        ]);

        // Si está cambiando la fecha/hora o el doctor, verificar disponibilidad
        if ((isset($validated['fecha']) || isset($validated['hora']) || isset($validated['id_doctor']))) {
            $doctor_id = $validated['id_doctor'] ?? $cita->id_doctor;
            $fecha = $validated['fecha'] ?? $cita->fecha;
            $hora = $validated['hora'] ?? $cita->hora;

            $citasExistentes = Citas::where('id_doctor', $doctor_id)
                ->whereDate('fecha', $fecha)
                ->whereTime('hora', $hora)
                ->where('id', '!=', $cita->id)
                ->where('estado', '!=', 'cancelada')
                ->count();

            if ($citasExistentes > 0) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'El doctor ya tiene una cita programada en este horario'
                ], 422);
            }
        }

        $cita->update($validated);

        // Si cambia el procedimiento, actualizamos el total
        if (isset($validated['id_procedimiento'])) {
            $total = Servicio::where('procedimiento_id', $validated['id_procedimiento'])->sum('precio');
            $cita->total = $total;
            $cita->save();
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Cita actualizada exitosamente',
            'data' => $cita->load(['doctor', 'paciente', 'procedimiento'])
        ]);
    }

    /**
     * Elimina una cita específica de la base de datos.
     *
     * @param Citas $cita
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Citas $cita, Request $request)
    {
        // Verificar que el usuario tenga permiso para eliminar esta cita
        $user = $request->user();
        if ($user->rol === 'doctor' && $cita->id_doctor != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para eliminar esta cita'
            ], 403);
        }

        $cita->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Cita eliminada exitosamente'
        ]);
    }

    /**
     * Obtiene las citas de un doctor específico.
     *
     * @param Doctor $doctor
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function citasPorDoctor(Doctor $doctor, Request $request)
    {
        $user = $request->user();
        
        // Solo los administradores pueden ver citas de cualquier doctor
        if ($user->rol === 'doctor' && $doctor->id != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para ver las citas de este doctor'
            ], 403);
        }

        $citas = Citas::with(['paciente', 'procedimiento'])
            ->where('id_doctor', $doctor->id)
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $citas
        ]);
    }

    /**
     * Obtiene las citas para una fecha específica.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function citasPorFecha(Request $request)
    {
        $validated = $request->validate([
            'fecha' => 'required|date|date_format:Y-m-d'
        ]);

        $user = $request->user();
        $query = Citas::with(['doctor', 'paciente', 'procedimiento'])
            ->whereDate('fecha', $validated['fecha']);

        // Si es doctor, solo ve sus citas
        if ($user->rol === 'doctor') {
            $query->where('id_doctor', $user->id_doctor);
        }

        $citas = $query->get();

        return response()->json([
            'status' => 'success',
            'data' => $citas
        ]);
    }

    /**
     * Obtiene el historial de citas de un doctor específico, separando pendientes y completadas.
     *
     * @param Doctor $doctor
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function historialCitasDoctor(Doctor $doctor, Request $request)
    {
        $user = $request->user();
        
        // Solo los administradores pueden ver citas de cualquier doctor
        if ($user->rol === 'doctor' && $doctor->id != $user->id_doctor) {
            return response()->json([
                'status' => 'error',
                'message' => 'No tiene permiso para ver el historial de citas de este doctor'
            ], 403);
        }

        // Obtener citas pendientes (programadas, confirmadas, reprogramadas)
        $citasPendientes = Citas::with(['paciente', 'procedimiento'])
            ->where('id_doctor', $doctor->id)
            ->whereIn('estado', ['programada', 'confirmada', 'reprogramada'])
            ->orderBy('fecha', 'asc')
            ->orderBy('hora', 'asc')
            ->get();

        // Obtener citas completadas o canceladas
        $citasCompletadas = Citas::with(['paciente', 'procedimiento'])
            ->where('id_doctor', $doctor->id)
            ->whereIn('estado', ['completada', 'cancelada'])
            ->orderBy('fecha', 'desc')
            ->orderBy('hora', 'desc')
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => [
                'pendientes' => $citasPendientes,
                'completadas' => $citasCompletadas
            ],
            'message' => 'Historial de citas del doctor recuperado exitosamente'
        ]);
    }
}

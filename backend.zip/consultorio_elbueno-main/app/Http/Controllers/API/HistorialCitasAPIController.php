<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\HistorialCitas;
use App\Models\Doctor;
use App\Models\Citas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HistorialCitasAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // Si hay un filtro por doctor
        if ($request->has('doctor')) {
            $historial = HistorialCitas::with(['doctor', 'paciente'])
                ->where('id_doctor', $request->doctor)
                ->orderBy('created_at', 'desc')
                ->get();
        } else {
            $historial = HistorialCitas::with(['doctor', 'paciente'])
                ->orderBy('created_at', 'desc')
                ->get();
        }
        
        return response()->json($historial);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'id_doctor' => 'required|exists:doctors,id',
            'id_paciente' => 'required|exists:pacientes,id',
            'procedimiento' => 'required|string',
            'fecha_cita' => 'required|date',
            'hora_cita' => 'required|date_format:H:i',
            'observaciones' => 'nullable|string',
            'estado_final' => 'required|string',
        ]);

        $historial = HistorialCitas::create($validatedData);
        return response()->json($historial, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $historial = HistorialCitas::with(['doctor', 'paciente'])->findOrFail($id);
        return response()->json($historial);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $historial = HistorialCitas::findOrFail($id);
        
        $validatedData = $request->validate([
            'id_doctor' => 'sometimes|exists:doctors,id',
            'id_paciente' => 'sometimes|exists:pacientes,id',
            'procedimiento' => 'sometimes|string',
            'fecha_cita' => 'sometimes|date',
            'hora_cita' => 'sometimes|date_format:H:i',
            'observaciones' => 'nullable|string',
            'estado_final' => 'sometimes|string',
        ]);

        $historial->update($validatedData);
        return response()->json($historial);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $historial = HistorialCitas::findOrFail($id);
        $historial->delete();
        return response()->json(null, 204);
    }
    
    /**
     * Get historial de citas for a specific doctor.
     */
    public function historialPorDoctor($doctorId)
    {
        try {
            $doctor = Doctor::findOrFail($doctorId);
            
            // Obtener citas completadas directamente del modelo Citas
            $citasCompletadas = Citas::with(['paciente', 'procedimiento'])
                ->where('id_doctor', $doctorId)
                ->whereIn('estado', ['Completada', 'completada', 'Cancelada', 'cancelada'])
                ->orderBy('fecha', 'desc')
                ->orderBy('hora', 'desc')
                ->get();
            
            // También obtener registros del historial de citas
            $historialCitas = HistorialCitas::where('id_doctor', $doctorId)
                ->with('paciente')
                ->orderBy('fecha_cita', 'desc')
                ->orderBy('hora_cita', 'desc')
                ->get();
                
            return response()->json([
                'doctor' => $doctor,
                'citas_completadas' => $citasCompletadas,
                'historial_citas' => $historialCitas
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al recuperar el historial de citas: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get statistics about a doctor's appointments.
     */
    public function estadisticasDoctor($doctorId)
    {
        $doctor = Doctor::findOrFail($doctorId);
        
        // Total de citas
        $totalCitas = HistorialCitas::where('id_doctor', $doctorId)->count();
        
        // Citas por estado
        $citasPorEstado = HistorialCitas::where('id_doctor', $doctorId)
            ->selectRaw('estado_final, COUNT(*) as total')
            ->groupBy('estado_final')
            ->get();
        
        // Pacientes más frecuentes
        $pacientesFrecuentes = HistorialCitas::where('id_doctor', $doctorId)
            ->selectRaw('id_paciente, COUNT(*) as total')
            ->with('paciente:id,nombre,apellido')
            ->groupBy('id_paciente')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(5)
            ->get();
        
        // Procedimientos más frecuentes
        $procedimientosFrecuentes = HistorialCitas::where('id_doctor', $doctorId)
            ->selectRaw('procedimiento, COUNT(*) as total')
            ->groupBy('procedimiento')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(5)
            ->get();
            
        return response()->json([
            'doctor' => $doctor,
            'estadisticas' => [
                'total_citas' => $totalCitas,
                'por_estado' => $citasPorEstado,
                'pacientes_frecuentes' => $pacientesFrecuentes,
                'procedimientos_frecuentes' => $procedimientosFrecuentes
            ]
        ]);
    }
}
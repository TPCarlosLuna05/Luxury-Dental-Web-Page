<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Procedimiento;
use Illuminate\Http\Request;

class ProcedimientoAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $procedimientos = Procedimiento::all();
        return response()->json($procedimientos);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
        ]);

        $procedimiento = Procedimiento::create($validatedData);
        return response()->json($procedimiento, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $procedimiento = Procedimiento::findOrFail($id);
        return response()->json($procedimiento);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $procedimiento = Procedimiento::findOrFail($id);
        
        $validatedData = $request->validate([
            'nombre' => 'sometimes|string|max:255',
            'descripcion' => 'sometimes|nullable|string',
        ]);

        $procedimiento->update($validatedData);
        return response()->json($procedimiento);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $procedimiento = Procedimiento::findOrFail($id);
        $procedimiento->delete();
        return response()->json(null, 204);
    }
}
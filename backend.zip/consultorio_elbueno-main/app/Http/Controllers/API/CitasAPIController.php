<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Citas;
use App\Models\Doctor;
use App\Models\Servicio;
use App\Models\HistorialMedico;
use App\Models\HistorialCitas;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Mail;

class CitasAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorId = $request->input('id_doctor');
            
            // Construir la consulta base - CITAS PENDIENTES, CONFIRMADAS, REPROGRAMADAS Y POR CONFIRMAR
            $query = Citas::with(['paciente', 'doctor', 'procedimiento'])
                ->whereIn('estado', ['Pendiente', 'pendiente', 'Confirmada', 'confirmada', 'Reprogramada', 'reprogramada', 'Por confirmar']);
            
            // Si es admin, puede ver todas las citas pendientes
            if ($rol === 'admin') {
                $citas = $query->get();
            } 
            // Si es doctor, solo ve sus citas pendientes
            elseif ($rol === 'doctor' && $doctorId) {
                $citas = $query->where('id_doctor', $doctorId)
                    ->get();
            } 
            // Si no se proporcionó rol o ID de doctor
            else {
                // Devolver todas las citas pendientes
                $citas = $query->get();
            }
            
            // Devolver directamente el array de citas para que el cliente pueda filtrar
            return response()->json($citas->toArray());
            
        } catch (\Exception $e) {
            \Log::error('Error al listar citas: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener las citas: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            // Validar los datos
            $validatedData = $request->validate([
                'id_paciente' => 'required|exists:pacientes,id',
                'id_doctor' => 'required|exists:doctors,id',
                'id_procedimiento' => 'nullable|exists:procedimientos,id',
                'descripcion_manual' => 'nullable|string',
                'observaciones' => 'nullable|string',
                'estado' => 'nullable|string',
                'fecha' => 'required|date',
                'hora' => 'required|date_format:H:i',
                'servicios' => 'nullable|array',
                'servicios.*.id' => 'required|exists:servicios,id',
                'servicios.*.cantidad' => 'required|integer|min:1'
            ]);

            // Asegurar que el estado sea "Por confirmar" para nuevas citas
            // Ignorar el estado proporcionado por el cliente
            $validatedData['estado'] = \App\Models\Citas::ESTADO_POR_CONFIRMAR;
            
            \Log::info('Creando nueva cita con estado: ' . $validatedData['estado']);

            // Extraer servicios si están presentes
            $servicios = $request->input('servicios', []);
            
            // Crear la cita dentro de una transacción
            $cita = DB::transaction(function () use ($validatedData, $servicios) {
                // Crear la cita
                $cita = Citas::create($validatedData);
                
                // Agregar servicios si los hay
                if (!empty($servicios)) {
                    $this->asociarServiciosACita($cita, $servicios);
                } 
                // Si no hay servicios directos pero hay un procedimiento, 
                // calcular el total basado en los servicios del procedimiento
                elseif ($cita->id_procedimiento) {
                    $cita->calcularTotal();
                }
                
                // Generar token de confirmación
                $cita->generarTokenConfirmacion();
                
                return $cita;
            });
            
            // Cargar relaciones para la respuesta
            $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);
            
            // Enviar enlace de confirmación (esto se implementaría en un método separado)
            $confirmationUrl = $this->enviarEnlaceConfirmacion($cita);
            
            return response()->json([
                'status' => 'success',
                'data' => $cita,
                'confirmation_url' => $confirmationUrl,
                'message' => 'Cita creada correctamente con estado Por confirmar'
            ], 201);
        } catch (\Exception $e) {
            \Log::error('Error al crear cita: ' . $e->getMessage(), [
                'exception' => $e,
                'datos' => $request->all()
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Error al crear la cita: ' . $e->getMessage(),
                'errors' => $e instanceof \Illuminate\Validation\ValidationException 
                    ? $e->errors() 
                    : null
            ], $e instanceof \Illuminate\Validation\ValidationException ? 422 : 500);
        }
    }

    /**
     * Crea una cita a partir del ID de servicio, extrayendo automáticamente el procedimiento.
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storePorServicio(Request $request)
    {
        try {
            // Validar los datos básicos de la cita
            $validatedData = $request->validate([
                'id_paciente' => 'required|exists:pacientes,id',
                'id_doctor' => 'required|exists:doctors,id',
                'id_servicio' => 'required|exists:servicios,id', // Nuevo campo para el ID del servicio
                'fecha' => 'required|date',
                'hora' => 'required|date_format:H:i',
                'observaciones' => 'nullable|string',
                'estado' => 'nullable|string',
            ]);

            // Buscar el servicio para obtener el procedimiento relacionado
            $servicio = Servicio::with('procedimiento')->findOrFail($validatedData['id_servicio']);
            
            // Preparar datos para la cita
            $citaData = [
                'id_paciente' => $validatedData['id_paciente'],
                'id_doctor' => $validatedData['id_doctor'],
                'id_procedimiento' => $servicio->procedimiento_id, // Asignar automáticamente el ID del procedimiento
                'fecha' => $validatedData['fecha'],
                'hora' => $validatedData['hora'],
                'observaciones' => $validatedData['observaciones'] ?? null,
                'estado' => \App\Models\Citas::ESTADO_POR_CONFIRMAR, // Siempre "Por confirmar" para nuevas citas
                'descripcion_manual' => null // No es necesario ya que usamos el procedimiento
            ];

            \Log::info('Creando nueva cita por servicio con estado: ' . $citaData['estado']);
            
            // Preparar el servicio para asociarlo a la cita
            $servicios = [
                [
                    'id' => $servicio->id,
                    'cantidad' => $request->input('cantidad', 1) // Cantidad por defecto es 1
                ]
            ];
            
            // Crear la cita dentro de una transacción
            $cita = DB::transaction(function () use ($citaData, $servicios) {
                // Crear la cita
                $cita = Citas::create($citaData);
                
                // Asociar el servicio a la cita
                $this->asociarServiciosACita($cita, $servicios);
                
                // Generar token de confirmación
                $cita->generarTokenConfirmacion();
                
                return $cita;
            });
            
            // Cargar relaciones para la respuesta
            $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);
            
            // Enviar enlace de confirmación y obtener la URL
            $confirmationUrl = $this->enviarEnlaceConfirmacion($cita);
            
            // Registrar la URL generada para debugging
            \Log::info('Enviando respuesta con URL de confirmación: ' . $confirmationUrl);
            
            // Usar success como clave para mantener consistencia con el frontend
            return response()->json([
                'success' => true, // Cambiado de 'status' a 'success' para mantener consistencia
                'data' => $cita,
                'confirmation_url' => $confirmationUrl, // Incluir la URL en la respuesta
                'message' => 'Cita creada correctamente con el servicio seleccionado'
            ], 201);
        } catch (\Exception $e) {
            \Log::error('Error al crear cita por servicio: ' . $e->getMessage(), [
                'exception' => $e,
                'datos' => $request->all()
            ]);

            return response()->json([
                'success' => false, // Cambiado para mantener consistencia
                'message' => 'Error al crear la cita: ' . $e->getMessage(),
                'errors' => $e instanceof \Illuminate\Validation\ValidationException 
                    ? $e->errors() 
                    : null
            ], $e instanceof \Illuminate\Validation\ValidationException ? 422 : 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($id, Request $request)
    {
        try {
            $cita = Citas::with(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos'])->findOrFail($id);
            
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorId = $request->input('id_doctor');
            
            // Si es doctor, verificar que la cita le pertenece
            if ($rol === 'doctor' && $doctorId && $cita->id_doctor != $doctorId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a ver esta cita'
                ], 403);
            }
            
            return response()->json([
                'status' => 'success',
                'data' => $cita,
                'message' => 'Cita recuperada exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al recuperar la cita: ' . $e->getMessage()
            ], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        try {
            $cita = Citas::findOrFail($id);
            
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorId = $request->input('id_doctor');
            
            // Si es doctor, verificar que la cita le pertenece
            if ($rol === 'doctor' && $doctorId && $cita->id_doctor != $doctorId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a actualizar esta cita'
                ], 403);
            }
            
            $validatedData = $request->validate([
                'id_paciente' => 'sometimes|exists:pacientes,id',
                'id_doctor' => 'sometimes|exists:doctors,id',
                'id_procedimiento' => 'sometimes|nullable|exists:procedimientos,id',
                'descripcion_manual' => 'sometimes|nullable|string',
                'observaciones' => 'sometimes|nullable|string',
                'estado' => 'sometimes|string',
                'fecha' => 'sometimes|date',
                'hora' => 'sometimes|date_format:H:i',
                'servicios' => 'sometimes|nullable|array',
                'servicios.*.id' => 'required|exists:servicios,id',
                'servicios.*.cantidad' => 'required|integer|min:1'
            ]);
            
            // Extraer servicios si están presentes
            $servicios = $request->input('servicios');
            
            // Actualizar cita dentro de una transacción
            $cita = DB::transaction(function () use ($cita, $validatedData, $servicios, $request) {
                // Normalizar el estado si se proporciona
                if (isset($validatedData['estado'])) {
                    $estado = strtolower($validatedData['estado']);
                    if ($estado === 'pendiente') {
                        $validatedData['estado'] = 'Pendiente';
                    } elseif ($estado === 'completada') {
                        $validatedData['estado'] = 'Completada';
                    } elseif ($estado === 'cancelada') {
                        $validatedData['estado'] = 'Cancelada';
                    }
                }

                // Detectar si la cita está cambiando a estado "Completada" o "Cancelada"
                $estadoAnterior = $cita->estado;
                $nuevoEstado = $validatedData['estado'] ?? $estadoAnterior;
                
                // Actualizar la cita
                $cita->update($validatedData);
                
                // Actualizar servicios si se proporcionaron
                if ($request->has('servicios')) {
                    // Eliminar servicios existentes y agregar los nuevos
                    $cita->serviciosDirectos()->detach();
                    if (!empty($servicios)) {
                        $this->asociarServiciosACita($cita, $servicios);
                    } 
                    // Si se eliminaron todos los servicios pero hay un procedimiento,
                    // recalcular el total basado en los servicios del procedimiento
                    elseif ($cita->id_procedimiento) {
                        $cita->calcularTotal();
                    }
                } 
                // Si cambió el procedimiento, pero no los servicios directos
                elseif (isset($validatedData['id_procedimiento'])) {
                    $cita->calcularTotal();
                }
                
                // SOLO si la cita cambió a "Completada", crear una entrada en el historial médico
                // No crear entradas para otros estados
                if ($nuevoEstado === 'Completada' && $estadoAnterior !== 'Completada') {
                    $this->crearHistorialMedico($cita);
                    \Log::info('Historial médico creado para la cita ID: ' . $cita->id);
                }
                
                // Si la cita cambió a "Cancelada", eliminar entradas del historial médico si existen
                if ($nuevoEstado === 'Cancelada' && $estadoAnterior !== 'Cancelada') {
                    $this->eliminarHistorialMedico($cita);
                }
                
                // SOLO si la cita cambió a "Completada", crear una entrada en el historial de citas
                // Las citas canceladas no deben aparecer en el historial del paciente
                if ($nuevoEstado === 'Completada' && $estadoAnterior !== 'Completada') {
                    $this->crearHistorialCitas($cita, $nuevoEstado);
                }
                
                return $cita;
            });
            
            // Recargar la cita con sus relaciones
            $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);

            return response()->json([
                'status' => 'success',
                'data' => $cita,
                'message' => 'Cita actualizada correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al actualizar la cita: ' . $e->getMessage(),
                'errors' => $e instanceof \Illuminate\Validation\ValidationException 
                    ? $e->errors() 
                    : null
            ], $e instanceof \Illuminate\Validation\ValidationException ? 422 : 500);
        }
    }

    /**
     * Crear un registro en el historial médico a partir de una cita completada.
     */
    private function crearHistorialMedico(Citas $cita)
    {
        // Verificación adicional: SOLO crear historial si la cita está completada
        if ($cita->estado !== 'Completada') {
            \Log::warning('Intento de crear historial médico para cita no completada (ID: ' . $cita->id . ', Estado: ' . $cita->estado . ')');
            return false;
        }
        
        // Cargar relaciones necesarias para verificación
        $cita->load('paciente', 'doctor', 'procedimiento');
        
        // Determinar el nombre del procedimiento para la verificación
        $nombreProcedimiento = '';
        if ($cita->procedimiento) {
            $nombreProcedimiento = $cita->procedimiento->nombre;
        } elseif ($cita->descripcion_manual) {
            $nombreProcedimiento = $cita->descripcion_manual;
        } else {
            $nombreProcedimiento = 'Consulta general';
        }
        
        // Verificación más estricta para evitar duplicados:
        // Buscar por paciente, fecha, doctor y procedimiento
        $existente = HistorialMedico::where('id_paciente', $cita->id_paciente)
            ->where('fecha', $cita->fecha)
            ->where('doctor', $cita->doctor->nombre)
            ->where('procedimiento', $nombreProcedimiento)
            ->first();
            
        if ($existente) {
            \Log::info('Ya existe un historial médico para la cita ID: ' . $cita->id . ' con el mismo procedimiento. No se creará otro.');
            return false;
        }
        
        // Nombre del doctor (ya tenemos cargadas las relaciones)
        $nombreDoctor = $cita->doctor ? $cita->doctor->nombre : 'Doctor no especificado';
        
        // El procedimiento ya está determinado en la verificación anterior
        
        // Crear el registro de historial médico
        HistorialMedico::create([
            'id_paciente' => $cita->id_paciente,
            'fecha' => $cita->fecha,
            'procedimiento' => $nombreProcedimiento,
            'doctor' => $nombreDoctor,
            'notas' => $cita->observaciones ?? 'Cita completada satisfactoriamente.',
        ]);
    }
    
    /**
     * Crear un registro en el historial de citas a partir de una cita completada o cancelada.
     */
    private function crearHistorialCitas(Citas $cita, $estadoFinal)
    {
        // Cargar relaciones necesarias
        $cita->load('paciente', 'doctor', 'procedimiento');
        
        // Determinar el nombre del procedimiento
        $nombreProcedimiento = '';
        if ($cita->procedimiento) {
            $nombreProcedimiento = $cita->procedimiento->nombre;
        } elseif ($cita->descripcion_manual) {
            $nombreProcedimiento = $cita->descripcion_manual;
        } else {
            $nombreProcedimiento = 'Consulta general';
        }
        
        // Crear el registro de historial de citas
        HistorialCitas::create([
            'id_doctor' => $cita->id_doctor,
            'id_paciente' => $cita->id_paciente,
            'procedimiento' => $nombreProcedimiento,
            'fecha_cita' => $cita->fecha,
            'hora_cita' => $cita->hora,
            'observaciones' => $cita->observaciones,
            'estado_final' => $estadoFinal,
        ]);
    }

    /**
     * Eliminar registros del historial médico asociados a una cita.
     */
    private function eliminarHistorialMedico(Citas $cita)
    {
        // Buscar y eliminar registros en historial médico que coincidan con el paciente y la fecha
        $historialEliminado = HistorialMedico::where('id_paciente', $cita->id_paciente)
            ->where('fecha', $cita->fecha)
            ->delete();
        
        \Log::info('Se eliminaron ' . $historialEliminado . ' registros del historial médico relacionados con la cita ID: ' . $cita->id);
        
        return $historialEliminado;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id, Request $request)
    {
        try {
            $cita = Citas::findOrFail($id);
            
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorId = $request->input('id_doctor');
            
            // Si es doctor, verificar que la cita le pertenece
            if ($rol === 'doctor' && $doctorId && $cita->id_doctor != $doctorId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a eliminar esta cita'
                ], 403);
            }
            
            // Antes de eliminar la cita, eliminar cualquier registro de historial médico relacionado
            $historialEliminado = $this->eliminarHistorialMedico($cita);
            
            // Eliminar la cita
            $cita->delete();
            
            // Mensaje personalizado según si se eliminaron registros del historial médico
            $mensaje = 'Cita eliminada exitosamente';
            if ($historialEliminado > 0) {
                $mensaje .= ' y se eliminaron ' . $historialEliminado . ' registros relacionados del historial médico';
            }
            
            return response()->json([
                'status' => 'success',
                'data' => null,
                'message' => $mensaje
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al eliminar la cita: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Obtener citas por doctor
     * GET /citas-por-doctor/{doctor}
     */
    public function citasPorDoctor($doctorId)
    {
        try {
            // Verificar si el doctor existe
            $doctor = Doctor::find($doctorId);
            if (!$doctor) {
                return response()->json([
                    'success' => false,
                    'message' => 'Doctor no encontrado'
                ], 404);
            }
            
            // Obtener las citas del doctor
            $citas = Citas::with(['paciente', 'procedimiento'])
                ->where('id_doctor', $doctorId)
                ->whereIn('estado', ['Pendiente', 'pendiente', 'Confirmada', 'confirmada', 'Reprogramada', 'reprogramada', 'Por confirmar'])
                ->get();
            
            // Devolver directamente un array JSON de citas para que el cliente pueda filtrar
            return response()->json($citas->toArray());
            
        } catch (\Exception $e) {
            \Log::error('Error al obtener citas por doctor: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener las citas: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Obtiene las citas filtradas por fecha.
     */
    public function citasPorFecha(Request $request)
    {
        try {
            $request->validate([
                'fecha' => 'required|date',
            ]);
            
            $fecha = $request->fecha;
            $rol = $request->input('rol');
            $doctorId = $request->input('id_doctor');
            
            $query = Citas::with(['paciente', 'doctor', 'procedimiento'])
                ->whereDate('fecha', $fecha);
                
            // Si es doctor, solo ve sus citas
            if ($rol === 'doctor' && $doctorId) {
                $query->where('id_doctor', $doctorId);
            }
            
            $citas = $query->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $citas,
                'message' => 'Citas por fecha recuperadas correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener citas por fecha: ' . $e->getMessage(),
                'errors' => $e instanceof \Illuminate\Validation\ValidationException 
                    ? $e->errors() 
                    : null
            ], $e instanceof \Illuminate\Validation\ValidationException ? 422 : 500);
        }
    }
    
    /**
     * Obtiene el historial de citas COMPLETADAS de un paciente específico.
     * Las citas canceladas no se incluyen en el historial del paciente.
     */
    public function historialCitasPorPaciente($pacienteId)
    {
        try {
            // Verificar si el paciente existe
            $paciente = \App\Models\Paciente::findOrFail($pacienteId);
            
            // Obtener SOLO las citas COMPLETADAS del paciente (no las canceladas)
            $historialCitas = Citas::with(['doctor', 'procedimiento'])
                ->where('id_paciente', $pacienteId)
                ->whereIn('estado', ['Completada', 'completada']) // Solo citas completadas
                ->orderBy('fecha', 'desc')
                ->orderBy('hora', 'desc')
                ->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $historialCitas,
                'message' => 'Historial de citas recuperado correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener el historial de citas: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Obtiene las próximas citas pendientes de un paciente.
     */
    public function proximasCitasPorPaciente($pacienteId)
    {
        try {
            // Verificar si el paciente existe
            $paciente = \App\Models\Paciente::findOrFail($pacienteId);
            
            // Obtener la fecha actual
            $hoy = now()->format('Y-m-d');
            
            // Obtener todas las citas pendientes del paciente a partir de hoy
            $proximasCitas = Citas::with(['doctor', 'procedimiento'])
                ->where('id_paciente', $pacienteId)
                ->whereIn('estado', ['Pendiente', 'pendiente']) // Para manejar ambos formatos
                ->where(function($query) use ($hoy) {
                    $query->where('fecha', '>', $hoy)
                          ->orWhere(function($q) use ($hoy) {
                              $q->where('fecha', '=', $hoy)
                                ->where('hora', '>=', now()->format('H:i:s'));
                          });
                })
                ->orderBy('fecha', 'asc')
                ->orderBy('hora', 'asc')
                ->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $proximasCitas,
                'message' => 'Próximas citas recuperadas correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener las próximas citas: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtiene el historial de citas de un doctor específico, separando pendientes y completadas.
     */
    public function historialCitasDoctor($doctorId, Request $request)
    {
        try {
            // Verificar si el doctor existe
            $doctor = Doctor::findOrFail($doctorId);
            
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorSolicitanteId = $request->input('id_doctor');
            
            // Solo admins o el propio doctor pueden ver su historial
            if ($rol === 'doctor' && $doctorSolicitanteId != $doctorId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a ver el historial de citas de este doctor'
                ], 403);
            }
            
            // Obtener citas pendientes (programadas y confirmadas) del doctor ordenadas por fecha y hora
            $citasPendientes = Citas::with(['paciente', 'procedimiento'])
                ->where('id_doctor', $doctorId)
                ->whereIn('estado', ['Pendiente', 'pendiente', 'Confirmada', 'confirmada', 'Reprogramada', 'reprogramada'])
                ->orderBy('fecha', 'asc')
                ->orderBy('hora', 'asc')
                ->get();
                
            // Obtener citas completadas o canceladas del doctor ordenadas por fecha descendente
            $citasCompletadas = Citas::with(['paciente', 'procedimiento'])
                ->where('id_doctor', $doctorId)
                ->whereIn('estado', ['Completada', 'completada', 'Cancelada', 'cancelada'])
                ->orderBy('fecha', 'desc')
                ->orderBy('hora', 'desc')
                ->get();
            
            return response()->json([
                'status' => 'success',
                'data' => [
                    'pendientes' => $citasPendientes,
                    'completadas' => $citasCompletadas
                ],
                'message' => 'Historial de citas del doctor recuperado exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener el historial de citas del doctor: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtiene solo las citas completadas o canceladas de un doctor específico.
     */
    public function citasCompletadasDoctor($doctorId, Request $request)
    {
        try {
            // Verificar si el doctor existe
            $doctor = Doctor::findOrFail($doctorId);
            
            // Obtener rol y ID del doctor desde los parámetros de la solicitud
            $rol = $request->input('rol');
            $doctorSolicitanteId = $request->input('id_doctor');
            
            // Solo admins o el propio doctor pueden ver sus citas completadas
            if ($rol === 'doctor' && $doctorSolicitanteId != $doctorId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a ver las citas completadas de este doctor'
                ], 403);
            }
            
            // Obtener citas completadas o canceladas del doctor ordenadas por fecha descendente
            $citasCompletadas = Citas::with(['paciente', 'procedimiento'])
                ->where('id_doctor', $doctorId)
                ->whereIn('estado', ['Completada', 'completada', 'Cancelada', 'cancelada'])
                ->orderBy('fecha', 'desc')
                ->orderBy('hora', 'desc')
                ->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $citasCompletadas,
                'message' => 'Citas completadas del doctor recuperadas exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener las citas completadas del doctor: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtiene todas las citas completadas con opción de filtrar por doctor.
     */
    public function todasCitasCompletadas(Request $request)
    {
        try {
            // Verificar permisos - solo admin debería ver esto
            $rol = $request->input('rol');
            if ($rol !== 'admin') {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No autorizado a ver todas las citas completadas'
                ], 403);
            }
            
            // Construir la consulta base para citas completadas o canceladas
            $query = Citas::with(['paciente', 'doctor', 'procedimiento'])
                ->whereIn('estado', ['Completada', 'completada', 'Cancelada', 'cancelada'])
                ->orderBy('fecha', 'desc')
                ->orderBy('hora', 'desc');
            
            // Filtrar por doctor si se proporciona un ID de doctor
            $doctorId = $request->input('doctor_id');
            if ($doctorId) {
                $query->where('id_doctor', $doctorId);
            }
            
            // Ejecutar la consulta
            $citasCompletadas = $query->get();
            
            // Si se filtró por doctor, agregar información del doctor
            $nombreDoctor = null;
            if ($doctorId) {
                $doctor = Doctor::find($doctorId);
                if ($doctor) {
                    $nombreDoctor = $doctor->nombre;
                }
            }
            
            return response()->json([
                'status' => 'success',
                'data' => $citasCompletadas,
                'doctor_filtrado' => $nombreDoctor,
                'message' => $nombreDoctor 
                    ? "Citas completadas del Dr. $nombreDoctor recuperadas exitosamente"
                    : "Todas las citas completadas recuperadas exitosamente"
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener las citas completadas: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Asocia servicios a una cita y calcula el total.
     */
    private function asociarServiciosACita(Citas $cita, array $servicios)
    {
        $total = 0;
        $serviciosPivot = [];
        
        foreach ($servicios as $servicio) {
            $servicioModel = Servicio::findOrFail($servicio['id']);
            $cantidad = $servicio['cantidad'];
            $precioUnitario = $servicioModel->precio;
            $subtotal = $precioUnitario * $cantidad;
            
            $serviciosPivot[$servicio['id']] = [
                'precio_unitario' => $precioUnitario,
                'cantidad' => $cantidad,
                'subtotal' => $subtotal
            ];
            
            $total += $subtotal;
        }
        
        // Asociar servicios con la cita en la tabla pivote
        $cita->serviciosDirectos()->attach($serviciosPivot);
        
        // Actualizar el total de la cita
        $cita->total = $total;
        $cita->save();
        
        return $total;
    }
    
    /**
     * Envia un enlace de confirmación al paciente.
     */
    private function enviarEnlaceConfirmacion(Citas $cita)
    {
        // Cargar el paciente si no está cargado
        if (!$cita->relationLoaded('paciente')) {
            $cita->load('paciente');
        }
        
        // Usar la URL de Heroku para entorno de producción o IP local para desarrollo
        $baseUrl = config('app.env') === 'production' 
            ? 'https://dentist-app-0fcf42a43c96.herokuapp.com' 
            : 'http://192.168.0.32:8000';
        
        // Generar URL para confirmación
        $token = $cita->confirmation_token ?: $cita->generarTokenConfirmacion();
        
        // Construir la URL correcta para la ruta de confirmación
        $url = $baseUrl . '/confirmacion/' . $token;
        
        // Para desarrollo, registramos la URL en los logs
        \Log::info('URL de confirmación para cita #' . $cita->id . ': ' . $url);
        
        // Marcar que se envió la confirmación
        $cita->confirmation_sent_at = now();
        $cita->save();
        
        // Siempre devolver la URL para que la app móvil pueda mostrarla
        return $url;
    }
    
    /**
     * Confirma una cita mediante un token de confirmación.
     */
    public function confirmarCita(Request $request)
    {
        try {
            $token = $request->token;
            
            // Buscar la cita por el token de confirmación
            $cita = Citas::where('confirmation_token', $token)->first();
            
            if (!$cita) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Token de confirmación inválido'
                ], 404);
            }
            
            // Verificar si la cita ya fue confirmada
            if ($cita->patient_confirmed) {
                return response()->json([
                    'status' => 'warning',
                    'message' => 'Esta cita ya ha sido confirmada anteriormente'
                ]);
            }
            
            // Confirmar la cita
            $cita->confirmarCita();
            
            return response()->json([
                'status' => 'success',
                'message' => 'Cita confirmada exitosamente',
                'data' => $cita
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al confirmar la cita: ' . $e->getMessage()
            ], 500);
        }
    }
}
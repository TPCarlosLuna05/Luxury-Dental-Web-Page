<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class DoctorAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $doctors = Doctor::all();
        // Devolver con formato estandarizado
        return response()->json([
            'status' => 'success',
            'data' => $doctors,
            'message' => 'Listado de doctores recuperado exitosamente'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validar los datos del doctor
        $validatedDoctor = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|string|email|max:255|unique:doctors',
            'telefono' => 'required|string|max:20',
            'especialidad' => 'nullable|string|max:255',
            'status' => 'required|string|in:activo,inactivo,vacaciones,licencia'
        ]);

        // Validar los datos del usuario
        $validatedUser = $request->validate([
            'usuario' => 'required|string|max:255|unique:usuarios,usuario',
            'password' => 'required|string|min:8',
            'rol' => 'sometimes|string|in:admin,doctor',
        ]);

        // Usar una transacción para garantizar que ambos registros se crean o ninguno
        try {
            DB::beginTransaction();

            // Crear el doctor
            $doctor = Doctor::create($validatedDoctor);

            // Crear el usuario asociado
            $user = User::create([
                'id_doctor' => $doctor->id,
                'usuario' => $validatedUser['usuario'],
                'password' => Hash::make($validatedUser['password']),
                'rol' => $validatedUser['rol'] ?? 'doctor', // Valor predeterminado 'doctor' si no se proporciona
            ]);

            DB::commit();

            return response()->json([
                'status' => 'success',
                'data' => [
                    'doctor' => $doctor,
                    'usuario' => [
                        'id' => $user->id_usuario,
                        'usuario' => $user->usuario,
                        'rol' => $user->rol
                    ]
                ],
                'message' => 'Doctor y usuario creados exitosamente'
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error al crear el doctor y usuario: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        try {
            $doctor = Doctor::with('user')->findOrFail($id);
            return response()->json([
                'status' => 'success',
                'data' => $doctor,
                'message' => 'Doctor recuperado exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Doctor no encontrado: ' . $e->getMessage()
            ], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        try {
            $doctor = Doctor::findOrFail($id);
            
            $validated = $request->validate([
                'nombre' => 'sometimes|required|string|max:255',
                'correo' => 'sometimes|required|string|email|max:255|unique:doctors,correo,' . $doctor->id,
                'telefono' => 'sometimes|required|string|max:20',
                'especialidad' => 'nullable|string|max:255',
                'status' => 'sometimes|required|string|in:activo,inactivo,vacaciones,licencia'
            ]);

            $doctor->update($validated);
            
            $userData = null;

            // Si también necesitas actualizar el usuario asociado
            if ($request->has('usuario') || $request->has('password') || $request->has('rol')) {
                $user = User::where('id_doctor', $doctor->id)->first();
                
                if ($user) {
                    $userValidated = $request->validate([
                        'usuario' => 'sometimes|required|string|max:255|unique:usuarios,usuario,' . $user->id_usuario . ',id_usuario',
                        'password' => 'sometimes|required|string|min:8',
                        'rol' => 'sometimes|string|in:admin,doctor',
                    ]);

                    $userData = [];
                    
                    if (isset($userValidated['usuario'])) {
                        $userData['usuario'] = $userValidated['usuario'];
                    }
                    
                    if (isset($userValidated['password'])) {
                        $userData['password'] = Hash::make($userValidated['password']);
                    }
                    
                    if (isset($userValidated['rol'])) {
                        $userData['rol'] = $userValidated['rol'];
                    }
                    
                    if (!empty($userData)) {
                        $user->update($userData);
                    }
                }
            }

            return response()->json([
                'status' => 'success',
                'data' => [
                    'doctor' => $doctor,
                    'usuario' => $userData ? $userData : null
                ],
                'message' => 'Doctor actualizado exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al actualizar el doctor: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            $doctor = Doctor::findOrFail($id);
            
            DB::beginTransaction();
            
            // Eliminar el usuario asociado primero para evitar problemas de integridad referencial
            User::where('id_doctor', $doctor->id)->delete();
            
            // Ahora eliminar el doctor
            $doctor->delete();
            
            DB::commit();

            return response()->json([
                'status' => 'success',
                'data' => null,
                'message' => 'Doctor y usuario asociado eliminados exitosamente'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error al eliminar el doctor: ' . $e->getMessage()
            ], 500);
        }
    }
}
<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Procedimiento;
use App\Models\Servicio;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ServicioAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $servicios = Servicio::with('procedimiento')->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $servicios
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener los servicios',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     * 
     * Crea un nuevo servicio y su procedimiento asociado en una sola operación.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Datos inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Usar una transacción para asegurar que se creen ambos registros o ninguno
            $servicio = DB::transaction(function () use ($request) {
                // Paso 1: Crear el procedimiento
                $procedimiento = Procedimiento::create([
                    'nombre' => $request->nombre,
                    'descripcion' => $request->descripcion ?? null,
                ]);

                // Paso 2: Crear el servicio asociado con el precio
                $servicio = Servicio::create([
                    'procedimiento_id' => $procedimiento->id,
                    'nombre' => $request->nombre,
                    'descripcion' => $request->descripcion ?? null,
                    'precio' => $request->precio,
                ]);

                // Cargar la relación para devolverla en la respuesta
                $servicio->load('procedimiento');
                
                return $servicio;
            });

            return response()->json([
                'status' => 'success',
                'message' => 'Servicio creado con éxito',
                'data' => $servicio
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al crear el servicio',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $servicio = Servicio::with('procedimiento')->findOrFail($id);
            
            return response()->json([
                'status' => 'success',
                'data' => $servicio
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Servicio no encontrado',
                'error' => $e->getMessage()
            ], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'nombre' => 'sometimes|required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'sometimes|required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Datos inválidos',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $servicio = Servicio::findOrFail($id);
            
            // Usar una transacción para actualizar ambos registros
            DB::transaction(function () use ($request, $servicio) {
                // Actualizar el procedimiento asociado si hay cambios de nombre o descripción
                if ($request->has('nombre') || $request->has('descripcion')) {
                    $procedimiento = $servicio->procedimiento;
                    
                    if ($procedimiento) {
                        $updates = [];
                        
                        if ($request->has('nombre')) {
                            $updates['nombre'] = $request->nombre;
                        }
                        
                        if ($request->has('descripcion')) {
                            $updates['descripcion'] = $request->descripcion;
                        }
                        
                        $procedimiento->update($updates);
                    }
                }
                
                // Actualizar el servicio
                $servicioUpdates = [];
                
                if ($request->has('nombre')) {
                    $servicioUpdates['nombre'] = $request->nombre;
                }
                
                if ($request->has('descripcion')) {
                    $servicioUpdates['descripcion'] = $request->descripcion;
                }
                
                if ($request->has('precio')) {
                    $servicioUpdates['precio'] = $request->precio;
                }
                
                $servicio->update($servicioUpdates);
            });
            
            // Recargar el servicio con sus relaciones para la respuesta
            $servicio->load('procedimiento');
            
            return response()->json([
                'status' => 'success',
                'message' => 'Servicio actualizado con éxito',
                'data' => $servicio
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al actualizar el servicio',
                'error' => $e->getMessage()
            ], $e instanceof \Illuminate\Database\Eloquent\ModelNotFoundException ? 404 : 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $servicio = Servicio::findOrFail($id);
            $procedimientoId = $servicio->procedimiento_id;
            
            DB::transaction(function () use ($servicio, $procedimientoId) {
                // Eliminar primero el servicio
                $servicio->delete();
                
                // Verificar si el procedimiento tiene otros servicios
                $tieneOtrosServicios = Servicio::where('procedimiento_id', $procedimientoId)->exists();
                
                // Si no tiene otros servicios, eliminar también el procedimiento
                if (!$tieneOtrosServicios) {
                    Procedimiento::find($procedimientoId)->delete();
                }
            });
            
            return response()->json([
                'status' => 'success',
                'message' => 'Servicio eliminado con éxito'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al eliminar el servicio',
                'error' => $e->getMessage()
            ], $e instanceof \Illuminate\Database\Eloquent\ModelNotFoundException ? 404 : 500);
        }
    }
    
    /**
     * Obtener servicios por procedimiento.
     */
    public function serviciosPorProcedimiento(string $procedimientoId)
    {
        try {
            $servicios = Servicio::where('procedimiento_id', $procedimientoId)
                ->with('procedimiento')
                ->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $servicios
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error al obtener los servicios por procedimiento',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

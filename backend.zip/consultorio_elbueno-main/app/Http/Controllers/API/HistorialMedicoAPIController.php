<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\HistorialMedico;
use App\Models\Paciente;
use Illuminate\Http\Request;

class HistorialMedicoAPIController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // Si hay un filtro por paciente
        if ($request->has('paciente')) {
            $historiales = HistorialMedico::with('paciente')
                ->where('id_paciente', $request->paciente)
                ->orderBy('fecha', 'desc')
                ->get();
        } else {
            $historiales = HistorialMedico::with('paciente')
                ->orderBy('fecha', 'desc')
                ->get();
        }
        
        return response()->json($historiales);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'id_paciente' => 'required|exists:pacientes,id',
            'fecha' => 'required|date',
            'procedimiento' => 'required|string',
            'doctor' => 'required|string',
            'notas' => 'nullable|string',
        ]);

        $historial = HistorialMedico::create($validatedData);
        return response()->json($historial, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $historial = HistorialMedico::with('paciente')->findOrFail($id);
        return response()->json($historial);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $historial = HistorialMedico::findOrFail($id);
        
        $validatedData = $request->validate([
            'id_paciente' => 'sometimes|exists:pacientes,id',
            'fecha' => 'sometimes|date',
            'procedimiento' => 'sometimes|string',
            'doctor' => 'sometimes|string',
            'notas' => 'sometimes|nullable|string',
        ]);

        $historial->update($validatedData);
        return response()->json($historial);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $historial = HistorialMedico::findOrFail($id);
        $historial->delete();
        return response()->json(null, 204);
    }
    
    /**
     * Get historial médico for a specific patient.
     */
    public function historialPorPaciente($pacienteId)
    {
        $paciente = Paciente::findOrFail($pacienteId);
        $historial = HistorialMedico::where('id_paciente', $pacienteId)
            ->orderBy('fecha', 'desc')
            ->get();
            
        return response()->json([
            'paciente' => $paciente,
            'historial' => $historial
        ]);
    }
}
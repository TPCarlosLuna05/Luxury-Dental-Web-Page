<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class DoctorController extends Controller
{
    /**
     * Obtiene listado de doctores
     *
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $doctors = Doctor::all();
        return response()->json([
            'status' => 'success',
            'data' => $doctors
        ]);
    }

    /**
     * Almacena un nuevo doctor en la base de datos y crea un usuario asociado.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        // Validar los datos del doctor
        $validatedDoctor = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|string|email|max:255|unique:doctors',
            'telefono' => 'required|string|max:20',
            'especialidad' => 'nullable|string|max:255',
            'status' => 'required|string|in:activo,inactivo,vacaciones,licencia'
        ]);

        // Validar los datos del usuario
        $validatedUser = $request->validate([
            'usuario' => 'required|string|max:255|unique:usuarios,usuario',
            'password' => 'required|string|min:8',
            'rol' => 'sometimes|string|in:admin,doctor',
        ]);

        // Usar una transacción para garantizar que ambos registros se crean o ninguno
        try {
            DB::beginTransaction();

            // Crear el doctor
            $doctor = Doctor::create($validatedDoctor);

            // Crear el usuario asociado
            $user = User::create([
                'id_doctor' => $doctor->id,
                'usuario' => $validatedUser['usuario'],
                'password' => Hash::make($validatedUser['password']),
                'rol' => $validatedUser['rol'] ?? 'doctor', // Valor predeterminado 'doctor' si no se proporciona
            ]);

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Doctor y usuario creados exitosamente',
                'data' => [
                    'doctor' => $doctor,
                    'usuario' => [
                        'id' => $user->id_usuario,
                        'usuario' => $user->usuario,
                        'rol' => $user->rol
                    ]
                ]
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error al crear el doctor y usuario: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Obtiene un doctor específico.
     *
     * @param Doctor $doctor
     * @return JsonResponse
     */
    public function show(Doctor $doctor): JsonResponse
    {
        // Cargar el usuario asociado al doctor
        $doctor->load('user');
        
        return response()->json([
            'status' => 'success',
            'data' => $doctor
        ]);
    }

    /**
     * Actualiza un doctor específico en la base de datos.
     *
     * @param Request $request
     * @param Doctor $doctor
     * @return JsonResponse
     */
    public function update(Request $request, Doctor $doctor): JsonResponse
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'correo' => 'sometimes|required|string|email|max:255|unique:doctors,correo,' . $doctor->id,
            'telefono' => 'sometimes|required|string|max:20',
            'especialidad' => 'nullable|string|max:255',
            'status' => 'sometimes|required|string|in:activo,inactivo,vacaciones,licencia'
        ]);

        $doctor->update($validated);

        // Si también necesitas actualizar el usuario asociado
        if ($request->has('usuario') || $request->has('password') || $request->has('rol')) {
            $user = User::where('id_doctor', $doctor->id)->first();
            
            if ($user) {
                $userValidated = $request->validate([
                    'usuario' => 'sometimes|required|string|max:255|unique:usuarios,usuario,' . $user->id_usuario . ',id_usuario',
                    'password' => 'sometimes|required|string|min:8',
                    'rol' => 'sometimes|string|in:admin,doctor',
                ]);

                $userData = [];
                
                if (isset($userValidated['usuario'])) {
                    $userData['usuario'] = $userValidated['usuario'];
                }
                
                if (isset($userValidated['password'])) {
                    $userData['password'] = Hash::make($userValidated['password']);
                }
                
                if (isset($userValidated['rol'])) {
                    $userData['rol'] = $userValidated['rol'];
                }
                
                if (!empty($userData)) {
                    $user->update($userData);
                }
            }
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Doctor actualizado exitosamente',
            'data' => $doctor
        ]);
    }

    /**
     * Elimina un doctor específico de la base de datos.
     *
     * @param Doctor $doctor
     * @return JsonResponse
     */
    public function destroy(Doctor $doctor): JsonResponse
    {
        try {
            DB::beginTransaction();
            
            // Eliminar el usuario asociado primero para evitar problemas de integridad referencial
            User::where('id_doctor', $doctor->id)->delete();
            
            // Ahora eliminar el doctor
            $doctor->delete();
            
            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Doctor y usuario asociado eliminados exitosamente'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error al eliminar el doctor: ' . $e->getMessage(),
            ], 500);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    /**
     * Devuelve la lista de doctores para el selector de inicio de sesión.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getDoctores()
    {
        $doctores = Doctor::where('status', 'activo')
                          ->select('id', 'nombre')
                          ->get();
        
        return response()->json([
            'status' => 'success',
            'data' => $doctores
        ]);
    }

    /**
     * Maneja el proceso de inicio de sesión.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $request->validate([
            'id_doctor' => 'required|exists:doctors,id',
            'password' => 'required|string',
        ]);

        $user = User::where('id_doctor', $request->id_doctor)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'password' => ['Las credenciales proporcionadas son incorrectas.'],
            ]);
        }

        // Cargamos los datos del doctor para devolverlos en la respuesta
        $user->load('doctor');

        // Crear token de autenticación
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'status' => 'success',
            'message' => 'Inicio de sesión exitoso',
            'data' => [
                'token' => $token,
                'user' => [
                    'id' => $user->id_usuario,
                    'usuario' => $user->usuario,
                    'rol' => $user->rol,
                    'is_admin' => $user->isAdmin(), // Añadimos la verificación de admin
                    'doctor' => $user->doctor
                ]
            ]
        ]);
    }

    /**
     * Cierra la sesión del usuario.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Sesión cerrada exitosamente'
        ]);
    }

    /**
     * Obtiene información del usuario autenticado.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function user(Request $request)
    {
        $user = $request->user();
        
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Usuario no autenticado'
            ], 401);
        }

        $user->load('doctor');

        return response()->json([
            'status' => 'success',
            'data' => [
                'user' => [
                    'id' => $user->id_usuario,
                    'usuario' => $user->usuario,
                    'rol' => $user->rol,
                    'is_admin' => $user->isAdmin(), // Añadimos la verificación de admin
                    'doctor' => $user->doctor
                ]
            ]
        ]);
    }
    
    /**
     * Inicia sesión para administradores (sin seleccionar doctor)
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function loginAdmin(Request $request)
    {
        $request->validate([
            'usuario' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = User::where('usuario', $request->usuario)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'usuario' => ['Las credenciales proporcionadas son incorrectas.'],
            ]);
        }

        // Verificar que sea administrador
        if (!$user->isAdmin()) {
            throw ValidationException::withMessages([
                'usuario' => ['Este usuario no tiene permisos de administrador.'],
            ]);
        }

        // Crear token de autenticación
        $token = $user->createToken('auth_token')->plainTextToken;

        // Cargar doctor si existe
        $user->load('doctor');

        return response()->json([
            'status' => 'success',
            'message' => 'Inicio de sesión como administrador exitoso',
            'data' => [
                'token' => $token,
                'user' => [
                    'id' => $user->id_usuario,
                    'usuario' => $user->usuario,
                    'rol' => $user->rol,
                    'is_admin' => true,
                    'doctor' => $user->doctor
                ]
            ]
        ]);
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Citas extends Model
{
    /** @use HasFactory<\Database\Factories\CitasFactory> */
    use HasFactory;
    
    /**
     * Constantes para los estados de la cita.
     */
    const ESTADO_POR_CONFIRMAR = 'Por confirmar';
    const ESTADO_PENDIENTE = 'Pendiente';
    const ESTADO_CONFIRMADA = 'Confirmada';
    const ESTADO_COMPLETADA = 'Completada';
    const ESTADO_CANCELADA = 'Cancelada';
    const ESTADO_REPROGRAMADA = 'Reprogramada';
    
    /**
     * Los atributos que son asignables masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id_paciente',
        'id_doctor',
        'id_procedimiento',
        'descripcion_manual',
        'observaciones',
        'estado',
        'fecha',
        'hora',
        'total',
        'confirmation_token',
        'confirmed_at',
        'patient_confirmed',
        'confirmation_sent_at',
    ];
    
    /**
     * Los atributos que deben convertirse a tipos nativos.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'fecha' => 'date',
        'hora' => 'datetime:H:i',
        'total' => 'decimal:2',
        'patient_confirmed' => 'boolean',
        'confirmed_at' => 'datetime',
        'confirmation_sent_at' => 'datetime',
    ];
    
    /**
     * Obtiene el paciente asociado a esta cita.
     */
    public function paciente()
    {
        return $this->belongsTo(Paciente::class, 'id_paciente');
    }
    
    /**
     * Obtiene el doctor asociado a esta cita.
     */
    public function doctor()
    {
        return $this->belongsTo(Doctor::class, 'id_doctor');
    }
    
    /**
     * Obtiene el procedimiento asociado a esta cita, si existe.
     */
    public function procedimiento()
    {
        return $this->belongsTo(Procedimiento::class, 'id_procedimiento');
    }
    
    /**
     * Obtiene los servicios asociados directamente a esta cita (relación muchos a muchos).
     */
    public function serviciosDirectos()
    {
        return $this->belongsToMany(Servicio::class, 'cita_servicio')
            ->withPivot('precio_unitario', 'cantidad', 'subtotal')
            ->withTimestamps();
    }
    
    /**
     * Obtiene los servicios asociados a esta cita a través del procedimiento.
     */
    public function serviciosPorProcedimiento()
    {
        return $this->hasMany(Servicio::class, 'procedimiento_id', 'id_procedimiento');
    }
    
    /**
     * Calcula el total de la cita en base a los precios de los servicios.
     */
    public function calcularTotal()
    {
        $total = 0;
        
        // Sumamos los subtotales de los servicios asociados directamente a la cita
        $total += $this->serviciosDirectos()->sum('subtotal');
        
        // Si hay un procedimiento y no se asignaron servicios directamente, 
        // sumamos los precios de todos sus servicios
        if ($this->id_procedimiento && $total == 0) {
            $total += $this->procedimiento->servicios->sum('precio');
        }
        
        $this->total = $total;
        $this->save();
        
        return $total;
    }
    
    /**
     * Genera un token de confirmación para la cita.
     */
    public function generarTokenConfirmacion()
    {
        $this->confirmation_token = Str::random(64);
        $this->confirmation_sent_at = now();
        $this->save();
        
        return $this->confirmation_token;
    }
    
    /**
     * Confirmar la cita por parte del paciente.
     */
    public function confirmarCita()
    {
        $this->patient_confirmed = true;
        $this->confirmed_at = now();
        
        // Cambiar el estado de "Por confirmar" a "Pendiente" cuando el paciente confirma
        if ($this->estado === self::ESTADO_POR_CONFIRMAR) {
            $this->estado = self::ESTADO_PENDIENTE;
        }
        
        $this->save();
    }
}

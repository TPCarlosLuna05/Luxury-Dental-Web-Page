<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Procedimiento extends Model
{
    /** @use HasFactory<\Database\Factories\ProcedimientoFactory> */
    use HasFactory;
    
    /**
     * Los atributos que son asignables masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'nombre',
        'descripcion'
    ];
    
    /**
     * Obtiene los servicios asociados a este procedimiento.
     */
    public function servicios()
    {
        return $this->hasMany(Servicio::class);
    }
    
    /**
     * Obtiene las citas asociadas a este procedimiento.
     */
    public function citas()
    {
        return $this->hasMany(Citas::class, 'id_procedimiento');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Servicio extends Model
{
    use HasFactory;

    /**
     * Los atributos que son asignables masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'procedimiento_id',
        'precio',
        'nombre',
        'descripcion',
    ];

    /**
     * Los atributos que deben convertirse a tipos nativos.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'precio' => 'decimal:2',
    ];

    /**
     * Obtiene el procedimiento asociado a este servicio.
     */
    public function procedimiento()
    {
        return $this->belongsTo(Procedimiento::class);
    }

    /**
     * Obtiene las citas que tienen este servicio asociado (relación muchos a muchos).
     */
    public function citasDirectas()
    {
        return $this->belongsToMany(Citas::class, 'cita_servicio')
            ->withPivot('precio_unitario', 'cantidad', 'subtotal')
            ->withTimestamps();
    }

    /**
     * Obtiene todas las citas que utilizan este servicio a través del procedimiento.
     */
    public function citasPorProcedimiento()
    {
        return $this->hasMany(Citas::class, 'id_procedimiento', 'procedimiento_id');
    }
}

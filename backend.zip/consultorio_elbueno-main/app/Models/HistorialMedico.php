<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistorialMedico extends Model
{
    use HasFactory;
    
    /**
     * La tabla asociada con el modelo.
     *
     * @var string
     */
    protected $table = 'historial_medicos';
    
    /**
     * Los atributos que son asignables masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id_paciente',
        'fecha',
        'procedimiento',
        'doctor',
        'notas',
    ];
    
    /**
     * Los atributos que deben convertirse a tipos nativos.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'fecha' => 'date',
    ];
    
    /**
     * Obtiene el paciente asociado a este historial médico.
     */
    public function paciente()
    {
        return $this->belongsTo(Paciente::class, 'id_paciente');
    }
}

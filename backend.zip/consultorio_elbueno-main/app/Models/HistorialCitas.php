<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistorialCitas extends Model
{
    use HasFactory;
    
    /**
     * La tabla asociada con el modelo.
     *
     * @var string
     */
    protected $table = 'historial_citas';
    
    /**
     * Los atributos que son asignables masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id_doctor',
        'id_paciente',
        'procedimiento',
        'fecha_cita',
        'hora_cita',
        'observaciones',
        'estado_final',
    ];
    
    /**
     * Los atributos que deben convertirse a tipos nativos.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'fecha_cita' => 'date',
        'hora_cita' => 'datetime:H:i',
    ];
    
    /**
     * Obtiene el doctor asociado a este historial.
     */
    public function doctor()
    {
        return $this->belongsTo(Doctor::class, 'id_doctor');
    }
    
    /**
     * Obtiene el paciente asociado a este historial.
     */
    public function paciente()
    {
        return $this->belongsTo(Paciente::class, 'id_paciente');
    }
}
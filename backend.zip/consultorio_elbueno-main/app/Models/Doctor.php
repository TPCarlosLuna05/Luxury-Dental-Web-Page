<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Doctor Model
 * 
 * @property int $id Identificador único del dentista
 * @property string $nombre Nombre completo del dentista
 * @property string $correo Email de contacto
 * @property string $telefono Número de teléfono del dentista
 * @property string|null $especialidad Especialidad del dentista (opcional)
 * @property string $status Estado general del dentista (activo, inactivo, etc.)
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 */
class Doctor extends Model
{
    /** @use HasFactory<\Database\Factories\DoctorFactory> */
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'nombre',
        'correo',
        'telefono',
        'especialidad',
        'status',
    ];

    /**
     * Obtiene el usuario asociado a este doctor.
     */
    public function user(): HasOne
    {
        return $this->hasOne(User::class, 'id_doctor', 'id');
    }
    
    /**
     * Obtiene el historial de citas asociado a este doctor.
     */
    public function historialCitas(): HasMany
    {
        return $this->hasMany(HistorialCitas::class, 'id_doctor');
    }
    
    /**
     * Obtiene las citas asociadas a este doctor.
     */
    public function citas(): HasMany
    {
        return $this->hasMany(Citas::class, 'id_doctor');
    }
}

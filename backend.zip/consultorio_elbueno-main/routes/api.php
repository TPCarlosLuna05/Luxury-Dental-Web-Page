<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\API\PacienteAPIController;
use App\Http\Controllers\API\ProcedimientoAPIController;
use App\Http\Controllers\API\CitasAPIController;
use App\Http\Controllers\API\HistorialMedicoAPIController;
use App\Http\Controllers\API\HistorialCitasAPIController;
use App\Http\Controllers\API\DoctorAPIController;
use App\Http\Controllers\API\ServicioAPIController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Rutas de autenticación
Route::get('/doctores-lista', [AuthController::class, 'getDoctores']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/login-admin', [AuthController::class, 'loginAdmin']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
Route::get('/user', [AuthController::class, 'user'])->middleware('auth:sanctum');

// Rutas para pacientes (sin autenticación)
Route::apiResource('pacientes', PacienteAPIController::class);

// Rutas para procedimientos (sin autenticación)
Route::apiResource('procedimientos', ProcedimientoAPIController::class);

// Rutas para servicios (tratamientos con precio)
Route::apiResource('servicios', ServicioAPIController::class);
Route::get('/servicios-por-procedimiento/{procedimiento}', [ServicioAPIController::class, 'serviciosPorProcedimiento']);

// Rutas para historial médico (sin autenticación)
Route::apiResource('historial-medico', HistorialMedicoAPIController::class);
Route::get('/historial-por-paciente/{paciente}', [HistorialMedicoAPIController::class, 'historialPorPaciente']);

// Rutas para historial de citas (sin autenticación)
Route::apiResource('historial-citas', HistorialCitasAPIController::class);
Route::get('/historial-citas-por-doctor/{doctor}', [HistorialCitasAPIController::class, 'historialPorDoctor']);
Route::get('/estadisticas-citas-doctor/{doctor}', [HistorialCitasAPIController::class, 'estadisticasDoctor']);

// Rutas para doctores (sin autenticación)
Route::apiResource('doctores', DoctorAPIController::class);

// Todas las rutas para citas (sin autenticación)
Route::apiResource('citas', CitasAPIController::class);
// Nueva ruta para crear citas proporcionando solo el ID del servicio
Route::post('/citas-por-servicio', [CitasAPIController::class, 'storePorServicio']);
// Ruta para confirmar citas por token (para pacientes)
Route::get('/citas/confirmar/{token}', [CitasAPIController::class, 'confirmarCita'])->name('api.citas.confirmar');

// Rutas adicionales para filtrar citas (sin autenticación)
Route::get('/citas-por-doctor/{doctor}', [CitasAPIController::class, 'citasPorDoctor']);
Route::get('/citas-por-fecha', [CitasAPIController::class, 'citasPorFecha']);

// Nuevas rutas para historial de citas y próximas citas de un paciente
Route::get('/historial-citas-paciente/{pacienteId}', [CitasAPIController::class, 'historialCitasPorPaciente']);
Route::get('/proximas-citas-paciente/{pacienteId}', [CitasAPIController::class, 'proximasCitasPorPaciente']);

// Nueva ruta para historial de citas de doctor
Route::get('/historial-citas-doctor/{doctorId}', [CitasAPIController::class, 'historialCitasDoctor']);

// Nueva ruta para citas completadas de un doctor
Route::get('/citas-completadas-doctor/{doctorId}', [CitasAPIController::class, 'citasCompletadasDoctor']);

// Nueva ruta para ver todas las citas completadas (filtrable por doctor)
Route::get('/todas-citas-completadas', [CitasAPIController::class, 'todasCitasCompletadas']);
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\CitasController;
use App\Http\Controllers\ServicioController;
use App\Http\Controllers\Web\CitaConfirmacionController;
use App\Models\Citas;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Nueva ruta para manejar la confirmación generada por la API (sin middleware signed)
Route::get('/confirmacion/{token}', function($token) {
    // Buscar la cita por el token
    $cita = Citas::where('confirmation_token', $token)->first();
    
    if (!$cita) {
        return view('error', [
            'mensaje' => 'Token de confirmación inválido o expirado'
        ]);
    }
    
    // Cargar relaciones necesarias, incluyendo servicios y sus precios
    $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);
    
    // Calcular el total de la cita si no está establecido
    if (!$cita->total || $cita->total == 0) {
        $cita->calcularTotal();
    }
    
    // Si la cita ya está confirmada o rechazada
    if ($cita->patient_confirmed) {
        return view('confirmacion', [
            'cita' => $cita,
            'accionRealizada' => 'Confirmada',
            'mensaje' => 'Esta cita ya había sido confirmada anteriormente.'
        ]);
    } elseif ($cita->estado === 'Cancelada') {
        return view('confirmacion', [
            'cita' => $cita,
            'accionRealizada' => 'Rechazada',
            'mensaje' => 'Esta cita ya había sido rechazada anteriormente.'
        ]);
    }
    
    // Mostrar la página con opciones para confirmar o rechazar
    return view('confirmacion', [
        'cita' => $cita
    ]);
});

// Rutas para confirmar o rechazar la cita
Route::post('/confirmacion/{token}/confirmar', function($token) {
    // Buscar la cita por el token
    $cita = Citas::where('confirmation_token', $token)->first();
    
    if (!$cita) {
        return view('error', [
            'mensaje' => 'Token de confirmación inválido o expirado'
        ]);
    }
    
    // Cargar relaciones necesarias, incluyendo servicios y sus precios
    $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);
    
    // Calcular el total de la cita si no está establecido
    if (!$cita->total || $cita->total == 0) {
        $cita->calcularTotal();
    }
    
    // Confirmar la cita
    if ($cita->estado === 'Por confirmar') {
        $cita->patient_confirmed = true;
        $cita->estado = 'Pendiente';
        $cita->save();
        
        // Registrar la confirmación en el log
        \Log::info('Cita #' . $cita->id . ' confirmada por el paciente. Estado cambiado a Pendiente.');
        
        return view('confirmacion', [
            'cita' => $cita,
            'accionRealizada' => 'Confirmada',
            'mensaje' => '¡Cita confirmada con éxito!'
        ]);
    } else {
        return view('confirmacion', [
            'cita' => $cita,
            'accionRealizada' => $cita->estado === 'Pendiente' ? 'Confirmada' : $cita->estado,
            'mensaje' => 'Esta cita ya no está disponible para confirmar.'
        ]);
    }
});

Route::post('/confirmacion/{token}/rechazar', function($token) {
    // Buscar la cita por el token
    $cita = Citas::where('confirmation_token', $token)->first();
    
    if (!$cita) {
        return view('error', [
            'mensaje' => 'Token de confirmación inválido o expirado'
        ]);
    }
    
    // Cargar relaciones necesarias, incluyendo servicios y sus precios
    $cita->load(['paciente', 'doctor', 'procedimiento', 'serviciosDirectos']);
    
    // Calcular el total de la cita si no está establecido
    if (!$cita->total || $cita->total == 0) {
        $cita->calcularTotal();
    }
    
    // Solo rechazar si la cita está por confirmar o pendiente
    if ($cita->estado === 'Por confirmar' || $cita->estado === 'Pendiente') {
        // Guardar una copia para mostrar en la vista
        $citaCopia = clone $cita;
        
        // Rechazar (cancelar) la cita
        $cita->estado = 'Cancelada';
        $cita->save();
        
        return view('confirmacion', [
            'cita' => $citaCopia,
            'accionRealizada' => 'Rechazada',
            'mensaje' => 'La cita ha sido rechazada y cancelada.'
        ]);
    } else {
        return view('confirmacion', [
            'cita' => $cita,
            'accionRealizada' => $cita->estado,
            'mensaje' => 'Esta cita ya no está disponible para rechazar.'
        ]);
    }
});

// Rutas de confirmación de citas (accesibles públicamente)
Route::get('/citas/confirmar/{token}', [CitaConfirmacionController::class, 'mostrarConfirmacion'])
    ->name('confirmacion.mostrar')
    ->middleware('signed');

Route::post('/citas/confirmar/{token}/accion', [CitaConfirmacionController::class, 'procesarConfirmacion'])
    ->name('citas.confirmar.accion');

Route::get('/citas/enlace-expirado', [CitaConfirmacionController::class, 'enlaceExpirado'])
    ->name('confirmacion.expirada');

// Rutas de autenticación
Route::get('/doctores-lista', [AuthController::class, 'getDoctores']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth');
Route::get('/user', [AuthController::class, 'user'])->middleware('auth');

// Rutas protegidas que requieren autenticación
Route::middleware('auth')->group(function () {
    // Rutas para doctores (solo admin puede crear/eliminar)
    Route::middleware('role:admin')->group(function () {
        Route::post('/doctores', [DoctorController::class, 'store']);
        Route::delete('/doctores/{doctor}', [DoctorController::class, 'destroy']);
    });
    
    Route::get('/doctores', [DoctorController::class, 'index']);
    Route::get('/doctores/{doctor}', [DoctorController::class, 'show']);
    Route::put('/doctores/{doctor}', [DoctorController::class, 'update'])->middleware('role:admin');
    
    // Rutas para citas
    Route::get('/citas', [CitasController::class, 'index']);
    Route::post('/citas', [CitasController::class, 'store']);
    Route::get('/citas/{cita}', [CitasController::class, 'show']);
    Route::put('/citas/{cita}', [CitasController::class, 'update']);
    Route::delete('/citas/{cita}', [CitasController::class, 'destroy']);
    
    // Rutas adicionales para filtrar citas
    Route::get('/citas-por-doctor/{doctor}', [CitasController::class, 'citasPorDoctor']);
    Route::get('/citas-por-fecha', [CitasController::class, 'citasPorFecha']);
    
    // Rutas para servicios
    Route::resource('servicios', ServicioController::class)->names([
        'index' => 'web.servicios.index',
        'create' => 'web.servicios.create',
        'store' => 'web.servicios.store',
        'show' => 'web.servicios.show',
        'edit' => 'web.servicios.edit',
        'update' => 'web.servicios.update',
        'destroy' => 'web.servicios.destroy',
    ]);
});

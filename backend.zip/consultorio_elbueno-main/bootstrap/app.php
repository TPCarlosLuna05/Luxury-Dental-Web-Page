<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

// Configurar silenciosamente la conexión PostgreSQL de Heroku sin mensajes
if (getenv('DATABASE_URL')) {
    $dbUrl = parse_url(getenv('DATABASE_URL'));
    if ($dbUrl && isset($dbUrl['host'])) {
        putenv('DB_CONNECTION=pgsql');
        putenv('DB_HOST='.$dbUrl['host']);
        putenv('DB_PORT='.($dbUrl['port'] ?? '5432'));
        putenv('DB_DATABASE='.substr($dbUrl['path'], 1));
        putenv('DB_USERNAME='.$dbUrl['user']);
        putenv('DB_PASSWORD='.$dbUrl['pass']);
    }
}

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        //
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();

<?php
// Este archivo está deshabilitado completamente
// La configuración de PostgreSQL ahora se maneja exclusivamente en bootstrap/app.php
return [];

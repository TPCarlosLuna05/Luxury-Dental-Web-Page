<?php
// Este archivo está deshabilitado porque la configuración ahora se maneja en bootstrap/app.php
return [];

// El código siguiente está comentado para evitar conflictos
/*
$databaseUrl = getenv('DATABASE_URL');

if ($databaseUrl) {
    // Parsear la URL para extraer componentes
    $parsed = parse_url($databaseUrl);

    if ($parsed !== false && isset($parsed['host'])) {
        // Extraer valores
        $host = $parsed['host'];
        $port = $parsed['port'] ?? '5432';
        $database = substr($parsed['path'], 1); // eliminar el / inicial
        $username = $parsed['user'];
        $password = $parsed['pass'];

        // Establecer variables de entorno para ser usadas por Laravel
        putenv("DB_CONNECTION=pgsql");
        putenv("DB_HOST=$host");
        putenv("DB_PORT=$port");
        putenv("DB_DATABASE=$database");
        putenv("DB_USERNAME=$username");
        putenv("DB_PASSWORD=$password");
    }
}
*/
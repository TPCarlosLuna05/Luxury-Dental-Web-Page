<?php

/**
 * Configuración especial para despliegue en Heroku
 */

// La configuración de PostgreSQL ahora se maneja en bootstrap/app.php
// Comentamos este código para evitar configuraciones duplicadas
/*
if ($databaseUrl = getenv('DATABASE_URL')) {
    $url = parse_url($databaseUrl);

    putenv('DB_CONNECTION=pgsql');
    putenv('DB_HOST=' . $url['host']);
    putenv('DB_PORT=' . $url['port']);
    putenv('DB_DATABASE=' . ltrim($url['path'], '/'));
    putenv('DB_USERNAME=' . $url['user']);
    putenv('DB_PASSWORD=' . $url['pass']);
}
*/

// Forzar HTTPS
if (getenv('APP_ENV') === 'production') {
    // Comentamos esta línea porque podría causar errores si se carga antes de que la aplicación esté lista
    // URL::forceScheme('https');
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Migración para corregir la tabla citas sin eliminarla
     */
    public function up(): void
    {
        // No usamos Schema::dropIfExists porque hay claves foráneas dependientes
        // En su lugar, modificamos la tabla existente
        
        // Verificar si existen las columnas necesarias y añadirlas si faltan
        if (!Schema::hasColumn('citas', 'id_procedimiento')) {
            Schema::table('citas', function (Blueprint $table) {
                $table->foreignId('id_procedimiento')->nullable()->constrained('procedimientos');
            });
        }
        
        // Añadir cualquier otra modificación que sea necesaria
        // ...
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Eliminar solo las columnas añadidas por esta migración
        if (Schema::hasColumn('citas', 'id_procedimiento')) {
            Schema::table('citas', function (Blueprint $table) {
                $table->dropForeign(['id_procedimiento']);
                $table->dropColumn('id_procedimiento');
            });
        }
    }
};

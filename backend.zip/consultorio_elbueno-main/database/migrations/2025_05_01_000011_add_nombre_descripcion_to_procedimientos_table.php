<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Esta migración es redundante porque las columnas ya existen
        // en la migración 2025_05_01_000006_create_procedimientos_table.php
        // No intentamos agregar las columnas nuevamente para evitar errores
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // No eliminamos las columnas para evitar problemas si fueron creadas por otra migración
        // Si necesitas eliminarlas en un rollback, verifica primero si existen
    }
};

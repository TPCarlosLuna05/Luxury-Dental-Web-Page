<?php

namespace Database\Factories;

use App\Models\Procedimiento;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Servicio>
 */
class ServicioFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'procedimiento_id' => Procedimiento::factory(),
            'nombre' => $this->faker->sentence(2),
            'descripcion' => $this->faker->paragraph(1),
            'precio' => $this->faker->randomFloat(2, 100, 5000),
        ];
    }
}

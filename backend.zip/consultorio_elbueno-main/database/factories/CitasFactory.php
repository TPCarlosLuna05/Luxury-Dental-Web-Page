<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Citas>
 */
class CitasFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $estados = ['pendiente', 'confirmada', 'completada', 'cancelada', 'reprogramada'];
        
        return [
            'id_paciente' => \App\Models\Paciente::inRandomOrder()->first()->id,
            'id_doctor' => \App\Models\Doctor::inRandomOrder()->first()->id,
            'id_procedimiento' => \App\Models\Procedimiento::inRandomOrder()->first()->id,
            'descripcion_manual' => $this->faker->optional()->text(100),
            'observaciones' => $this->faker->optional()->text(200),
            'estado' => $this->faker->randomElement($estados),
            'fecha' => $this->faker->dateTimeBetween('-1 month', '+2 months'),
            'hora' => $this->faker->time('H:i'),
        ];
    }
}

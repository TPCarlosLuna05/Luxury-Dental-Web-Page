<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Doctor;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DoctorAlbertoSeeder extends Seeder
{
    public function run(): void
    {
        $doctor = Doctor::create([
            'nombre' => 'Dr. Alberto Mendez',
            'correo' => 'alberto.mendez@clinica.com',
            'telefono' => '555-789-1234',
            'especialidad' => 'Medicina General',
            'status' => 'activo',
        ]);

        User::create([
            'id_doctor' => $doctor->id,
            'usuario' => 'alberto',
            'password' => Hash::make('1210'),
            'rol' => 'admin',
        ]);
    }
}
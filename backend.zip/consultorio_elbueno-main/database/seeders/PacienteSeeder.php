<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Paciente;

class PacienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Datos predefinidos para 10 pacientes reales
        $pacientes = [
            [
                'nombre' => 'Juan',
                'apellidos' => 'Pérez Gómez',
                'telefono' => '555-123-4567',
                'correo' => 'juan.perez@example.com',
                'descripcion' => 'Paciente con historial de problemas dentales',
                'fecha_registro' => '2024-01-15'
            ],
            [
                'nombre' => 'María',
                'apellidos' => 'López Sánchez',
                'telefono' => '555-234-5678',
                'correo' => 'maria.lopez@example.com',
                'descripcion' => 'Primera consulta para limpieza dental',
                'fecha_registro' => '2024-02-20'
            ],
            [
                'nombre' => 'Carlos',
                'apellidos' => 'Rodríguez Martínez',
                'telefono' => '555-345-6789',
                'correo' => 'carlos.rodriguez@example.com',
                'descripcion' => 'Requiere tratamiento de ortodoncia',
                'fecha_registro' => '2024-03-05'
            ],
            [
                'nombre' => 'Ana',
                'apellidos' => 'González Flores',
                'telefono' => '555-456-7890',
                'correo' => 'ana.gonzalez@example.com',
                'descripcion' => 'Consulta por dolor en muela del juicio',
                'fecha_registro' => '2024-03-15'
            ],
            [
                'nombre' => 'Roberto',
                'apellidos' => 'Hernández Luna',
                'telefono' => '555-567-8901',
                'correo' => 'roberto.hernandez@example.com',
                'descripcion' => 'Paciente con sensibilidad dental',
                'fecha_registro' => '2024-04-01'
            ],
            [
                'nombre' => 'Laura',
                'apellidos' => 'Torres Vega',
                'telefono' => '555-678-9012',
                'correo' => 'laura.torres@example.com',
                'descripcion' => 'Necesita revisión para blanqueamiento dental',
                'fecha_registro' => '2024-04-12'
            ],
            [
                'nombre' => 'Miguel',
                'apellidos' => 'Díaz Castro',
                'telefono' => '555-789-0123',
                'correo' => 'miguel.diaz@example.com',
                'descripcion' => 'Paciente nuevo, primera consulta general',
                'fecha_registro' => '2024-04-20'
            ],
            [
                'nombre' => 'Sofía',
                'apellidos' => 'Vargas Reyes',
                'telefono' => '555-890-1234',
                'correo' => 'sofia.vargas@example.com',
                'descripcion' => 'Consulta por problemas de encías',
                'fecha_registro' => '2024-05-03'
            ],
            [
                'nombre' => 'Alejandro',
                'apellidos' => 'Morales Jiménez',
                'telefono' => '555-901-2345',
                'correo' => 'alejandro.morales@example.com',
                'descripcion' => 'Requiere extracción dental',
                'fecha_registro' => '2024-05-08'
            ],
            [
                'nombre' => 'Patricia',
                'apellidos' => 'Ortiz Medina',
                'telefono' => '555-012-3456',
                'correo' => 'patricia.ortiz@example.com',
                'descripcion' => 'Paciente para seguimiento de tratamiento',
                'fecha_registro' => '2024-05-10'
            ]
        ];

        // Crear los registros de pacientes
        foreach ($pacientes as $pacienteData) {
            Paciente::create($pacienteData);
        }
    }
}

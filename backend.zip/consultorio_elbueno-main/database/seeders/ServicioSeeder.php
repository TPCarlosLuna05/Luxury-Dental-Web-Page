<?php

namespace Database\Seeders;

use App\Models\Procedimiento;
use App\Models\Servicio;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ServicioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Obtenemos todos los procedimientos existentes
        $procedimientos = Procedimiento::all();
        
        // Si no hay procedimientos, creamos algunos
        if ($procedimientos->isEmpty()) {
            $procedimientos = Procedimiento::factory()->count(5)->create();
        }
        
        // Para cada procedimiento, creamos entre 1 y 3 servicios con precios
        foreach ($procedimientos as $procedimiento) {
            Servicio::factory()->count(rand(1, 3))->create([
                'procedimiento_id' => $procedimiento->id,
                'nombre' => 'Servicio para ' . $procedimiento->nombre,
            ]);
        }
    }
}

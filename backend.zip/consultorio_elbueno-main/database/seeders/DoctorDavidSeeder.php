<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Doctor;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DoctorDavidSeeder extends Seeder
{
    public function run(): void
    {
        $doctor = Doctor::create([
            'nombre' => 'Dr. Carlos Rodríguez',
            'correo' => 'carlos.rodriguez@clinica.com',
            'telefono' => '555-123-4567',
            'especialidad' => 'Cardiología',
            'status' => 'activo',
        ]);

        User::create([
            'id_doctor' => $doctor->id,
            'usuario' => 'david',
            'password' => Hash::make('1234'),
            'rol' => 'doctor',
        ]);
    }
}

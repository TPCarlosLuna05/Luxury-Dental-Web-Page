<?php

namespace Database\Seeders;

use App\Models\Doctor;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DoctorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Datos predefinidos para doctores
        $doctores = [
            [
                'nombre' => 'Dr. Alberto Martínez',
                'correo' => 'alberto.martinez@dentalclinic.com',
                'telefono' => '555-111-2222',
                'especialidad' => 'Odontología General',
                'status' => 'activo'
            ],
            [
                'nombre' => 'Dra. Carmen Jiménez',
                'correo' => 'carmen.jimenez@dentalclinic.com',
                'telefono' => '555-222-3333',
                'especialidad' => 'Ortodoncia',
                'status' => 'activo'
            ],
            [
                'nombre' => 'Dr. David Sánchez',
                'correo' => 'david.sanchez@dentalclinic.com',
                'telefono' => '555-333-4444',
                'especialidad' => 'Cirugía Oral',
                'status' => 'activo'
            ]
        ];

        // Crear los registros de doctores
        foreach ($doctores as $doctorData) {
            Doctor::create($doctorData);
        }
    }
}

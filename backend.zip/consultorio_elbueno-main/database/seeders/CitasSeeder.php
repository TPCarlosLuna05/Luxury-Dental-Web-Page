<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CitasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Verificar que existan pacientes, doctores y procedimientos antes de crear citas
        if (\App\Models\Paciente::count() > 0 && 
            \App\Models\Doctor::count() > 0 && 
            \App\Models\Procedimiento::count() > 0) {
            
            // Crear 20 citas aleatorias
            \App\Models\Citas::factory()->count(20)->create();
            
            // Crear algunas citas para el día de hoy y mañana con hora específica
            $doctores = \App\Models\Doctor::all();
            $pacientes = \App\Models\Paciente::all();
            $procedimientos = \App\Models\Procedimiento::all();
            
            // Fechas para hoy y mañana
            $hoy = now()->format('Y-m-d');
            $manana = now()->addDay()->format('Y-m-d');
            
            // Horas específicas
            $horas = ['09:00', '10:30', '12:00', '15:30', '17:00'];
            
            foreach ($doctores as $doctor) {
                // 2 citas para hoy
                for ($i = 0; $i < 2; $i++) {
                    \App\Models\Citas::create([
                        'id_paciente' => $pacientes->random()->id,
                        'id_doctor' => $doctor->id,
                        'id_procedimiento' => $procedimientos->random()->id,
                        'descripcion_manual' => null,
                        'observaciones' => 'Cita automática para hoy',
                        'estado' => 'pendiente',
                        'fecha' => $hoy,
                        'hora' => $horas[array_rand($horas)],
                    ]);
                }
                
                // 1 cita para mañana
                \App\Models\Citas::create([
                    'id_paciente' => $pacientes->random()->id,
                    'id_doctor' => $doctor->id,
                    'id_procedimiento' => $procedimientos->random()->id,
                    'descripcion_manual' => null,
                    'observaciones' => 'Cita automática para mañana',
                    'estado' => 'pendiente',
                    'fecha' => $manana,
                    'hora' => $horas[array_rand($horas)],
                ]);
            }
        }
    }
}

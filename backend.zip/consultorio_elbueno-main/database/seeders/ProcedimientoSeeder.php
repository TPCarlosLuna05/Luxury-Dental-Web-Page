<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Procedimiento;

class ProcedimientoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $procedimientos = [
            [
                'nombre' => 'Revisión dental',
                'descripcion' => 'Evaluación inicial del paciente. Incluye examen visual de dientes, encías y tejidos blandos para detectar problemas como caries, enfermedad periodontal o lesiones.'
            ],
            [
                'nombre' => 'Limpieza dental (profilaxis)',
                'descripcion' => 'Procedimiento preventivo que elimina la placa y el sarro de las superficies dentales. Incluye pulido para eliminar manchas superficiales.'
            ],
            [
                'nombre' => 'Consulta',
                'descripcion' => 'Consulta general, de diagnóstico o para discutir un plan de tratamiento específico. Puede incluir revisión de historial médico y dental.'
            ],
            [
                'nombre' => 'Radiografía dental',
                'descripcion' => 'Imagen diagnóstica que permite visualizar estructuras no visibles en el examen clínico. Puede ser periapical, panorámica, de aleta de mordida u otro tipo según las necesidades específicas.'
            ],
            [
                'nombre' => 'Urgencia dental',
                'descripcion' => 'Atención inmediata para casos que requieren intervención rápida como dolor agudo, traumatismos, infecciones, sangrado o restauraciones perdidas.'
            ],
        ];

        foreach ($procedimientos as $procedimiento) {
            Procedimiento::create($procedimiento);
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {   
        // Ejecutar los seeders (sin CitasSeeder)
        $this->call([
            DoctorSeeder::class,
            PacienteSeeder::class,
            ProcedimientoSeeder::class,
            ServicioSeeder::class,
        ]);
    }
}

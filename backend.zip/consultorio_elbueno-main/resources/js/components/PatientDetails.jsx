import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import api from '../services/api';

const { width: screenWidth } = Dimensions.get('window');

export default function PatientDetails() {
  const navigation = useNavigation();
  const route = useRoute();
  const { patient } = route.params || {};
  const [historialMedico, setHistorialMedico] = useState([]);
  const [loadingHistorial, setLoadingHistorial] = useState(true);
  const [citas, setCitas] = useState([]);
  const [loadingCitas, setLoadingCitas] = useState(true);
  const carouselRef = useRef(null);

  useEffect(() => {
    // Si tenemos un paciente, cargar su historial médico y citas
    if (patient && patient.id) {
      fetchHistorialMedico(patient.id);
      fetchCitasPaciente(patient.id);
    }
  }, [patient]);

  const fetchHistorialMedico = async (pacienteId) => {
    try {
      setLoadingHistorial(true);
      const response = await api.get(`/historial-por-paciente/${pacienteId}`);
      
      console.log('Respuesta del historial médico:', response.data);
      
      // Verificar si la respuesta tiene datos en la estructura correcta
      if (response.data && response.data.historial) {
        setHistorialMedico(response.data.historial);
      } else {
        console.log('No se encontró historial para el paciente');
        setHistorialMedico([]);
      }
    } catch (error) {
      console.error('Error al cargar el historial médico:', error);
      setHistorialMedico([]);
    } finally {
      setLoadingHistorial(false);
    }
  };

  // Función para cargar citas del paciente
  const fetchCitasPaciente = async (pacienteId) => {
    try {
      setLoadingCitas(true);
      const response = await api.get(`/historial-citas-paciente/${pacienteId}`);
      
      console.log('Respuesta de historial de citas del paciente:', response.data);
      
      if (response.data && response.data.status === 'success' && response.data.data) {
        setCitas(response.data.data);
      } else {
        console.log('No se encontraron citas completadas para el paciente');
        setCitas([]);
      }
    } catch (error) {
      console.error('Error al cargar historial de citas del paciente:', error);
      setCitas([]);
    } finally {
      setLoadingCitas(false);
    }
  };

  // ... resto del código existente ...
}
<!DOCTYPE html>
<html>
<head>
    <title>Error - Confirmación de Cita</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 600px;
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #F44336;
            margin-top: 0;
        }
        .error-icon {
            font-size: 60px;
            color: #F44336;
            margin-bottom: 10px;
        }
        .message {
            padding: 15px;
            margin: 15px 0;
            background-color: #FFEBEE;
            border-left: 4px solid #F44336;
            color: #B71C1C;
        }
        .back-button {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            margin-top: 20px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #0D47A1;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-icon">✗</div>
        <h1>Error en la Confirmación</h1>
        
        <div class="message">
            {{ $mensaje ?? 'Ha ocurrido un error al procesar tu solicitud.' }}
        </div>
        
        <p>No se pudo procesar la confirmación de la cita. Es posible que el enlace haya expirado o sea inválido.</p>
        
        <p>Por favor, contacta al consultorio para más información o para programar una nueva cita.</p>
        
        <a href="/" class="back-button">Volver al Inicio</a>
        
        <p><small>Consultorio Médico - © {{ date('Y') }}</small></p>
    </div>
</body>
</html>
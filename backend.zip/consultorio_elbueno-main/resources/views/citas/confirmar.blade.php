@extends('layouts.app')

@section('title', 'Confirmación de Cita')
@section('subtitle', 'Confirmación de su Cita Médica')

@section('content')
    <div class="text-center">
        @if(session('status') === 'success')
            <div class="alert alert-success mb-4">
                {{ session('message') }}
            </div>
        @elseif(session('status') === 'warning')
            <div class="alert alert-error mb-4">
                {{ session('message') }}
            </div>
        @elseif(session('status') === 'error')
            <div class="alert alert-error mb-4">
                {{ session('message') }}
            </div>
        @endif

        <h2 class="mb-4">Detalles de su Cita</h2>
        
        @if(isset($cita))
            <div style="max-width: 600px; margin: 0 auto; text-align: left;">
                <div style="padding: 15px; background-color: #f3f4f6; border-radius: 8px; margin-bottom: 20px;">
                    <p><strong>Paciente:</strong> {{ $cita->paciente->nombre }}</p>
                    <p><strong>Doctor:</strong> {{ $cita->doctor->nombre }}</p>
                    <p><strong>Fecha:</strong> {{ $cita->fecha->format('d/m/Y') }}</p>
                    <p><strong>Hora:</strong> {{ \Carbon\Carbon::parse($cita->hora)->format('h:i A') }}</p>
                    
                    @if($cita->procedimiento)
                        <p><strong>Procedimiento:</strong> {{ $cita->procedimiento->nombre }}</p>
                    @endif
                    
                    <p><strong>Total a pagar:</strong> ${{ number_format($cita->total, 2) }}</p>
                    
                    @if(count($cita->serviciosDirectos) > 0)
                        <div style="margin-top: 15px;">
                            <p><strong>Servicios incluidos:</strong></p>
                            <ul style="list-style-type: none; padding-left: 10px;">
                                @foreach($cita->serviciosDirectos as $servicio)
                                    <li>
                                        {{ $servicio->nombre }} - 
                                        ${{ number_format($servicio->pivot->precio_unitario, 2) }} x 
                                        {{ $servicio->pivot->cantidad }} = 
                                        ${{ number_format($servicio->pivot->subtotal, 2) }}
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>
                
                @if(!$cita->patient_confirmed)
                    <form method="POST" action="{{ route('citas.confirmar.accion', ['token' => $token]) }}" style="text-align: center;">
                        @csrf
                        <p class="mb-4">¿Confirma su asistencia a esta cita médica?</p>
                        <div>
                            <button type="submit" name="action" value="confirm" class="btn btn-success">
                                Confirmar Cita
                            </button>
                            <button type="submit" name="action" value="cancel" class="btn btn-danger" style="margin-left: 10px;">
                                Cancelar Cita
                            </button>
                        </div>
                    </form>
                @else
                    <div class="alert alert-success text-center">
                        <p>Esta cita ya ha sido confirmada.</p>
                        <p>¡Gracias por confirmar su asistencia!</p>
                        <p>Lo esperamos el día {{ $cita->fecha->format('d/m/Y') }} a las {{ \Carbon\Carbon::parse($cita->hora)->format('h:i A') }}.</p>
                    </div>
                @endif
            </div>
        @else
            <div class="alert alert-error">
                <p>No se ha encontrado la información de la cita solicitada.</p>
                <p>Por favor, contacte al consultorio para más información.</p>
            </div>
        @endif
        
        <div class="mt-4">
            <p>Si tiene alguna pregunta o necesita reprogramar, llame al consultorio:</p>
            <p><strong>Teléfono:</strong> (123) 456-7890</p>
        </div>
    </div>
@endsection
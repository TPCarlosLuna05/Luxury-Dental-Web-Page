@extends('layouts.app')

@section('title', 'Enlace Expirado')
@section('subtitle', 'Enlace de Confirmación Expirado')

@section('content')
    <div class="text-center">
        <div class="alert alert-error mb-4">
            <p>El enlace de confirmación ha expirado o no es válido.</p>
        </div>
        
        <h2 class="mb-4">¿Qué puede hacer ahora?</h2>
        
        <div style="max-width: 600px; margin: 0 auto;">
            <p>Los enlaces de confirmación son válidos solo por 7 días desde que se programó su cita.</p>
            <p>Si desea confirmar su cita o necesita reprogramarla, por favor contacte directamente con el consultorio:</p>
            
            <div style="padding: 15px; background-color: #f3f4f6; border-radius: 8px; margin: 20px 0;">
                <p><strong>Teléfono:</strong> (123) 456-7890</p>
                <p><strong>Email:</strong> citas@consultorio.com</p>
                <p><strong>Horario de atención:</strong> Lunes a Viernes de 9:00 AM a 6:00 PM</p>
            </div>
            
            <p>Por favor, proporcione su nombre completo y la fecha de su cita cuando se comunique con nosotros.</p>
        </div>
        
        <div class="mt-4">
            <a href="/" class="btn btn-primary">Regresar a la página principal</a>
        </div>
    </div>
@endsection
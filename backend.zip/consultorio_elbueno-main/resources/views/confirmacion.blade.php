<!DOCTYPE html>
<html>
<head>
    <title>Confirmación de Cita</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 600px;
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #4CAF50;
            margin-top: 0;
        }
        .details {
            margin: 20px 0;
            text-align: left;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        .detail-row {
            margin-bottom: 10px;
        }
        .label {
            font-weight: bold;
        }
        .success-icon {
            font-size: 60px;
            color: #4CAF50;
            margin-bottom: 10px;
        }
        .question-icon {
            font-size: 60px;
            color: #2196F3;
            margin-bottom: 10px;
        }
        .message {
            padding: 10px;
            margin: 15px 0;
            background-color: #e8f5e9;
            border-left: 4px solid #4CAF50;
            color: #2e7d32;
        }
        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .btn-confirm {
            background-color: #4CAF50;
            color: white;
        }
        .btn-confirm:hover {
            background-color: #388E3C;
        }
        .btn-reject {
            background-color: #F44336;
            color: white;
        }
        .btn-reject:hover {
            background-color: #D32F2F;
        }
    </style>
</head>
<body>
    <div class="container">
        @if(isset($accionRealizada))
            <div class="success-icon">✓</div>
            <h1>Cita {{ $accionRealizada }}</h1>
            
            @if(isset($mensaje))
                <div class="message">
                    {{ $mensaje }}
                </div>
            @endif
            
            <div class="details">
                <div class="detail-row">
                    <span class="label">Paciente:</span> 
                    {{ $cita->paciente->nombre }}
                </div>
                <div class="detail-row">
                    <span class="label">Doctor:</span>
                    {{ $cita->doctor->nombre }}
                </div>
                <div class="detail-row">
                    <span class="label">Fecha:</span>
                    {{ \Carbon\Carbon::parse($cita->fecha)->format('d/m/Y') }}
                </div>
                <div class="detail-row">
                    <span class="label">Hora:</span>
                    {{ \Carbon\Carbon::parse($cita->hora)->format('H:i') }}
                </div>
                @if($cita->procedimiento)
                <div class="detail-row">
                    <span class="label">Procedimiento:</span>
                    {{ $cita->procedimiento->nombre }}
                </div>
                @endif
                <div class="detail-row">
                    <span class="label">Estado actual:</span>
                    <strong>{{ $cita->estado }}</strong>
                </div>
            </div>
              @if($accionRealizada == 'Confirmada')
                <p>Gracias por confirmar tu cita. Te esperamos en la fecha y hora indicadas.</p>
                @if($cita->total > 0)
                <p style="margin-top: 15px; font-weight: bold;">
                    Recuerda que el total a pagar por el servicio es: 
                    <span style="color: #4CAF50; font-size: 1.2em;">${{ number_format($cita->total, 2) }}</span>
                </p>
                @endif
            @else
                <p>La cita ha sido rechazada y cancelada exitosamente.</p>
                <p style="margin-top: 15px;">Si deseas programar una nueva cita en otro horario o con otro servicio, por favor contacta al consultorio.</p>
            @endif
        @else            <div class="question-icon">?</div>
            <h1>Confirmar Cita</h1>
            
            <p>Por favor confirma o rechaza la cita con los siguientes detalles:</p>
            
            <div class="details">
                <div class="detail-row">
                    <span class="label">Paciente:</span> 
                    {{ $cita->paciente->nombre }} {{ $cita->paciente->apellidos ?? '' }}
                </div>
                <div class="detail-row">
                    <span class="label">Doctor:</span>
                    {{ $cita->doctor->nombre }} {{ $cita->doctor->apellidos ?? '' }}
                </div>
                <div class="detail-row">
                    <span class="label">Fecha:</span>
                    {{ \Carbon\Carbon::parse($cita->fecha)->format('d/m/Y') }}
                </div>
                <div class="detail-row">
                    <span class="label">Hora:</span>
                    {{ \Carbon\Carbon::parse($cita->hora)->format('H:i') }}
                </div>
                @if($cita->procedimiento)
                <div class="detail-row">
                    <span class="label">Procedimiento:</span>
                    {{ $cita->procedimiento->nombre }}
                </div>
                @endif
                @if(isset($cita->serviciosDirectos) && count($cita->serviciosDirectos) > 0)
                <div class="detail-row">
                    <span class="label">Servicios:</span>
                    <ul style="margin-top: 5px; padding-left: 20px;">
                        @foreach($cita->serviciosDirectos as $servicio)
                            <li>{{ $servicio->nombre }} - ${{ number_format($servicio->precio, 2) }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
                @if($cita->total > 0)
                <div class="detail-row" style="margin-top: 15px; font-size: 1.1em;">
                    <span class="label">Total a pagar:</span>
                    <span style="color: #4CAF50; font-weight: bold;">${{ number_format($cita->total, 2) }}</span>
                </div>
                @endif
            </div>
            
            <div class="buttons-container">
                <form method="POST" action="{{ url('/confirmacion/' . $cita->confirmation_token . '/confirmar') }}">
                    @csrf
                    <button type="submit" class="btn btn-confirm">Confirmar Cita</button>
                </form>
                
                <form method="POST" action="{{ url('/confirmacion/' . $cita->confirmation_token . '/rechazar') }}">
                    @csrf
                    <button type="submit" class="btn btn-reject">Rechazar Cita</button>
                </form>
            </div>
        @endif
        
        <p><small>Consultorio Médico - © {{ date('Y') }}</small></p>
    </div>
</body>
</html>